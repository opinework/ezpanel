# XrayM - Installation Guide

## Quick Install

```bash
# Extract the archive
tar -xzf xraym-*.tar.gz
cd xraym-*/

# Run install script
sudo ./scripts/install.sh
```

## Manual Installation

### 1. Install Binary

```bash
sudo install -Dm755 bin/xraym /usr/bin/xraym
```

### 2. Install Configuration

```bash
sudo install -dm755 /etc/xraym
sudo install -Dm644 etc/config.yml /etc/xraym/config.yml
```

### 3. Install Systemd Service (Optional)

```bash
sudo install -Dm644 systemd/xraym.service \
    /lib/systemd/system/xraym.service
sudo systemctl daemon-reload
```

### 4. Start Service

```bash
sudo systemctl enable --now xraym
```

### 5. Run Manually

```bash
/usr/bin/xraym -config /etc/xraym/config.yml
```
