#!/usr/bin/env bash
set -euo pipefail

if [ "$(id -u)" -ne 0 ]; then
    echo "This script must be run as root"
    exit 1
fi

INSTALL_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

echo "Installing XrayM..."

# Create xraym user and group
if ! getent group xraym >/dev/null; then
    groupadd -r xraym
fi
if ! getent passwd xraym >/dev/null; then
    useradd -r -g xraym -d /var/lib/xraym -s /usr/sbin/nologin -c "XrayM Proxy Manager" xraym
fi

install -Dm755 "$INSTALL_DIR/bin/xraym" /usr/bin/xraym

install -dm755 /etc/xraym
install -Dm600 -o xraym -g xraym "$INSTALL_DIR/etc/config.yml" /etc/xraym/config.yml

# Create data directories
install -dm755 -o xraym -g xraym /var/lib/xraym
install -dm755 -o xraym -g xraym /var/log/xraym
install -dm755 -o xraym -g xraym /etc/xraym/certs

if [ -d /lib/systemd/system ]; then
    install -Dm644 "$INSTALL_DIR/systemd/xraym.service" /lib/systemd/system/xraym.service
    systemctl daemon-reload || true
fi

echo "========================================"
echo "XrayM installed."
echo "Edit /etc/xraym/config.yml before start."
echo "Start: sudo systemctl enable --now xraym"
echo "========================================"
