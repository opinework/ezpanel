# EzPanel 安装指南

本文档提供 EzPanel 在各种 Linux 发行版上的详细安装步骤。

---

## 📋 目录

- [系统要求](#系统要求)
- [Arch Linux 安装](#arch-linux-安装)
- [Debian/Ubuntu 安装](#debianubuntu-安装)
- [CentOS/RHEL 安装](#centosrhel-安装)
- [通用二进制安装](#通用二进制安装)
- [配置说明](#配置说明)
- [升级与卸载](#升级与卸载)
- [故障排除](#故障排除)

---

## 系统要求

### 硬件要求
- **CPU**: 1 核心+
- **内存**: 最低 512MB，推荐 1GB+
- **磁盘**: 最低 500MB 可用空间

### 软件要求
- **操作系统**: Linux (x86_64 / aarch64)
- **数据库**: MySQL 8.0+ 或 **MariaDB 10.5+** (推荐)
- **缓存**: Redis 6.0+ / Valkey 7.0+ (可选，用于性能优化)
- **网络**: 能够访问互联网（用于下载安装包）

---

## Arch Linux 安装

### 1. 安装数据库和缓存

```bash
# 安装 MariaDB
sudo pacman -S mariadb

# 初始化数据库
sudo mariadb-install-db --user=mysql --basedir=/usr --datadir=/var/lib/mysql

# 启动 MariaDB 服务
sudo systemctl start mariadb
sudo systemctl enable mariadb

# 安全配置 (设置 root 密码)
sudo mariadb-secure-installation

# 安装 Valkey (Redis 替代品)
sudo pacman -S valkey

# 启动 Valkey 服务
sudo systemctl start valkey
sudo systemctl enable valkey
```

### 2. 创建数据库

```bash
# 登录 MariaDB
sudo mariadb -u root -p
```

```sql
-- 创建数据库
CREATE DATABASE ezpanel CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- 创建用户并授权
CREATE USER 'ezpanel'@'localhost' IDENTIFIED BY 'your_secure_password';
GRANT ALL PRIVILEGES ON ezpanel.* TO 'ezpanel'@'localhost';
FLUSH PRIVILEGES;

-- 退出
EXIT;
```

### 3. 安装 EzPanel

```bash
# 下载安装包
wget https://github.com/opinework/ezpanel/releases/latest/download/ezpanel-x86_64.pkg.tar.zst

# 或使用 ARM64 版本
# wget https://github.com/opinework/ezpanel/releases/latest/download/ezpanel-aarch64.pkg.tar.zst

# 安装
sudo pacman -U ezpanel-*.pkg.tar.zst

# 确认安装
ezpanel --version
```

### 4. 配置 EzPanel

```bash
# 编辑配置文件
sudo vim /etc/ezpanel/config.yaml
```

修改以下配置：

```yaml
database:
  host: "localhost"
  port: 3306
  user: "ezpanel"
  password: "your_secure_password"  # 修改为刚才设置的密码
  dbname: "ezpanel"

redis:
  host: "localhost"  # Valkey 兼容 Redis 协议
  port: 6379
  password: ""
  db: 0

jwt:
  secret: "change-this-to-a-random-string-min-32-chars"  # 务必修改！
```

### 5. 启动服务

```bash
# 启动 ezpanel
sudo systemctl start ezpanel

# 设置开机自启
sudo systemctl enable ezpanel

# 查看服务状态
sudo systemctl status ezpanel

# 查看实时日志
sudo journalctl -u ezpanel -f
```

### 6. 访问面板

打开浏览器访问: `http://your-server-ip:7088`

- **默认账号**: `admin@opine.work`
- **默认密码**: `admin123`

> ⚠️ **首次登录后请立即修改默认密码！**

---

## Debian/Ubuntu 安装

### 1. 更新系统

```bash
# 更新软件包列表
sudo apt update
sudo apt upgrade -y
```

### 2. 安装数据库和缓存

```bash
# 安装 MariaDB
sudo apt install mariadb-server mariadb-client -y

# 启动 MariaDB
sudo systemctl start mariadb
sudo systemctl enable mariadb

# 安全配置
sudo mysql_secure_installation
# 按提示设置 root 密码

# 安装 Redis
sudo apt install redis-server -y

# 启动 Redis
sudo systemctl start redis-server
sudo systemctl enable redis-server

# 验证 Redis 状态
sudo systemctl status redis-server
```

### 3. 创建数据库

```bash
# 登录 MariaDB
sudo mariadb -u root -p
```

```sql
-- 创建数据库
CREATE DATABASE ezpanel CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- 创建用户
CREATE USER 'ezpanel'@'localhost' IDENTIFIED BY 'your_secure_password';
GRANT ALL PRIVILEGES ON ezpanel.* TO 'ezpanel'@'localhost';
FLUSH PRIVILEGES;

-- 验证权限
SHOW GRANTS FOR 'ezpanel'@'localhost';

-- 退出
EXIT;
```

### 4. 下载并安装 EzPanel

```bash
# 下载安装包 (x86_64)
wget https://github.com/opinework/ezpanel/releases/latest/download/ezpanel_amd64.deb

# 或 ARM64 版本
# wget https://github.com/opinework/ezpanel/releases/latest/download/ezpanel_arm64.deb

# 安装
sudo dpkg -i ezpanel_*.deb

# 如果有依赖问题，运行
sudo apt-get install -f

# 验证安装
ezpanel --version
```

### 5. 配置 EzPanel

```bash
# 编辑配置文件
sudo nano /etc/ezpanel/config.yaml
```

修改以下配置：

```yaml
database:
  host: "localhost"
  port: 3306
  user: "ezpanel"
  password: "your_secure_password"
  dbname: "ezpanel"

redis:
  host: "localhost"
  port: 6379
  password: ""
  db: 0

jwt:
  secret: "CHANGE_THIS_TO_RANDOM_STRING_32_CHARS"  # 务必修改！
  expire: 24
```

按 `Ctrl+O` 保存，`Ctrl+X` 退出。

### 6. 启动服务

```bash
# 启动服务
sudo systemctl start ezpanel

# 开机自启
sudo systemctl enable ezpanel

# 检查状态
sudo systemctl status ezpanel

# 查看日志
sudo journalctl -u ezpanel -n 50 --no-pager
```

### 7. 配置防火墙

```bash
# 如果使用 ufw
sudo ufw allow 7088/tcp
sudo ufw reload

# 如果使用 iptables
sudo iptables -A INPUT -p tcp --dport 7088 -j ACCEPT
sudo netfilter-persistent save
```

### 8. 访问面板

浏览器访问: `http://your-server-ip:7088`

默认登录：
- 账号: `admin@opine.work`
- 密码: `admin123`

---

## CentOS/RHEL 安装

### 1. 安装数据库

```bash
# CentOS/RHEL 8+
sudo dnf install mariadb-server mariadb -y

# 启动 MariaDB
sudo systemctl start mariadb
sudo systemctl enable mariadb

# 安全配置
sudo mysql_secure_installation
```

### 2. 安装 Redis

```bash
# 启用 EPEL 仓库
sudo dnf install epel-release -y

# 安装 Redis
sudo dnf install redis -y

# 启动 Redis
sudo systemctl start redis
sudo systemctl enable redis
```

### 3. 创建数据库

```bash
sudo mariadb -u root -p
```

```sql
CREATE DATABASE ezpanel CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER 'ezpanel'@'localhost' IDENTIFIED BY 'your_secure_password';
GRANT ALL PRIVILEGES ON ezpanel.* TO 'ezpanel'@'localhost';
FLUSH PRIVILEGES;
EXIT;
```

### 4. 使用通用二进制安装

由于 CentOS/RHEL 没有官方 .rpm 包，请使用[通用二进制安装](#通用二进制安装)方式。

---

## 通用二进制安装

适用于所有 Linux 发行版。

### 1. 下载并解压

```bash
# 下载 (x86_64)
wget https://github.com/opinework/ezpanel/releases/latest/download/ezpanel-linux-amd64.tar.gz

# 或 ARM64 版本
# wget https://github.com/opinework/ezpanel/releases/latest/download/ezpanel-linux-arm64.tar.gz

# 解压
tar -xzf ezpanel-linux-*.tar.gz
cd ezpanel-*
```

### 2. 安装二进制

```bash
# 复制二进制文件
sudo cp ezpanel /usr/bin/
sudo chmod +x /usr/bin/ezpanel

# 验证安装
ezpanel --version
```

### 3. 创建系统用户

```bash
# 创建专用用户 (不能登录)
sudo useradd -r -s /usr/sbin/nologin -d /var/lib/ezpanel ezpanel

# 或在某些系统上使用
sudo useradd -r -s /sbin/nologin -d /var/lib/ezpanel ezpanel
```

### 4. 创建目录结构

```bash
# 创建配置目录
sudo mkdir -p /etc/ezpanel

# 复制配置文件
sudo cp config.yaml /etc/ezpanel/

# 创建数据目录
sudo mkdir -p /var/lib/ezpanel/themes
sudo mkdir -p /var/log/ezpanel
sudo mkdir -p /var/lib/ezpanel/upload

# 设置权限
sudo chown -R ezpanel:ezpanel /var/lib/ezpanel
sudo chown -R ezpanel:ezpanel /var/log/ezpanel
sudo chown ezpanel:ezpanel /etc/ezpanel/config.yaml
sudo chmod 600 /etc/ezpanel/config.yaml
```

### 5. 创建 Systemd 服务

```bash
# 创建服务文件
sudo tee /etc/systemd/system/ezpanel.service > /dev/null <<'EOF'
[Unit]
Description=EzPanel VPN Management Panel
Documentation=https://github.com/opinework/ezpanel
After=network.target mariadb.service redis.service

[Service]
Type=simple
User=ezpanel
Group=ezpanel
WorkingDirectory=/var/lib/ezpanel
ExecStart=/usr/bin/ezpanel -config /etc/ezpanel/config.yaml
Restart=on-failure
RestartSec=5s
LimitNOFILE=65536

# 安全选项
PrivateTmp=true
ProtectSystem=strict
ReadWritePaths=/var/lib/ezpanel /var/log/ezpanel
NoNewPrivileges=true

[Install]
WantedBy=multi-user.target
EOF

# 重载 systemd
sudo systemctl daemon-reload
```

### 6. 配置并启动

```bash
# 编辑配置文件
sudo vim /etc/ezpanel/config.yaml
# 修改数据库密码和 JWT secret

# 启动服务
sudo systemctl start ezpanel
sudo systemctl enable ezpanel

# 查看状态
sudo systemctl status ezpanel
```

---

## 配置说明

### 最小配置

`/etc/ezpanel/config.yaml` 必须修改的配置项：

```yaml
database:
  password: "your_secure_password"  # 修改为实际密码

jwt:
  secret: "change-to-random-32-chars-string"  # 务必修改为随机字符串
```

### 生成随机 JWT Secret

```bash
# 方法 1: 使用 openssl
openssl rand -base64 32

# 方法 2: 使用 /dev/urandom
head -c 32 /dev/urandom | base64

# 方法 3: 使用 uuidgen
echo "$(uuidgen)$(uuidgen)" | tr -d '-'
```

### 完整配置示例

```yaml
# 服务器配置
server:
  host: "0.0.0.0"
  port: 7088
  mode: "release"
  theme_dir: "/var/lib/ezpanel/themes"

# 数据库配置 (MariaDB/MySQL)
database:
  host: "localhost"
  port: 3306
  user: "ezpanel"
  password: "your_secure_password"
  dbname: "ezpanel"
  charset: "utf8mb4"
  max_idle_conns: 10
  max_open_conns: 100

# Redis/Valkey 配置
redis:
  host: "localhost"
  port: 6379
  password: ""
  db: 0

# JWT 认证配置
jwt:
  secret: "your-random-secret-key-min-32-chars"
  expire: 24
  issuer: "ezpanel"

# 日志配置
log:
  level: "warn"       # debug / info / warn / error
  format: "console"   # json / console
  output: "stdout"    # stdout / file / both
  file_path: "/var/log/ezpanel/app.log"

# Swagger API 文档
swagger:
  enable: false       # 生产环境建议关闭

# 节点监控
node:
  report_metrics: true

# 上传配置
upload:
  path: "/var/lib/ezpanel/upload"
  max_size: 10
  allowed_types:
    - image/jpeg
    - image/png
    - image/gif
    - image/webp

# CORS 跨域
cors:
  allow_origins:
    - "*"             # 生产环境改为具体域名
  allow_credentials: true
  max_age: 12
```

### 环境变量覆盖

也可以使用环境变量覆盖配置：

```bash
export EZPANEL_DB_HOST=localhost
export EZPANEL_DB_USER=ezpanel
export EZPANEL_DB_PASSWORD=your_password
export EZPANEL_JWT_SECRET=your_secret_key
```

---

## 升级与卸载

### 升级

#### Arch Linux

```bash
# 下载新版本
wget https://github.com/opinework/ezpanel/releases/latest/download/ezpanel-x86_64.pkg.tar.zst

# 升级
sudo pacman -U ezpanel-*.pkg.tar.zst

# 重启服务
sudo systemctl restart ezpanel
```

配置文件如有更新会保存为 `/etc/ezpanel/config.yaml.pacnew`，请手动合并。

#### Debian/Ubuntu

```bash
# 下载新版本
wget https://github.com/opinework/ezpanel/releases/latest/download/ezpanel_amd64.deb

# 升级
sudo dpkg -i ezpanel_*.deb

# 重启服务
sudo systemctl restart ezpanel
```

#### 通用二进制

```bash
# 停止服务
sudo systemctl stop ezpanel

# 备份旧版本
sudo cp /usr/bin/ezpanel /usr/bin/ezpanel.backup

# 下载新版本
wget https://github.com/opinework/ezpanel/releases/latest/download/ezpanel-linux-amd64.tar.gz
tar -xzf ezpanel-linux-amd64.tar.gz

# 替换二进制
sudo cp ezpanel-*/ezpanel /usr/bin/

# 启动服务
sudo systemctl start ezpanel
```

### 卸载

#### Arch Linux

```bash
# 停止并禁用服务
sudo systemctl stop ezpanel
sudo systemctl disable ezpanel

# 卸载软件包
sudo pacman -R ezpanel

# 清理数据 (可选)
sudo rm -rf /var/lib/ezpanel
sudo rm -rf /var/log/ezpanel
sudo rm -rf /etc/ezpanel
```

#### Debian/Ubuntu

```bash
# 停止服务
sudo systemctl stop ezpanel
sudo systemctl disable ezpanel

# 卸载 (保留配置)
sudo apt remove ezpanel

# 完全卸载 (删除配置)
sudo apt purge ezpanel

# 清理数据
sudo rm -rf /var/lib/ezpanel
sudo rm -rf /var/log/ezpanel
```

#### 通用二进制

```bash
# 停止服务
sudo systemctl stop ezpanel
sudo systemctl disable ezpanel

# 删除文件
sudo rm /usr/bin/ezpanel
sudo rm /etc/systemd/system/ezpanel.service
sudo rm -rf /etc/ezpanel
sudo rm -rf /var/lib/ezpanel
sudo rm -rf /var/log/ezpanel

# 删除用户
sudo userdel ezpanel

# 重载 systemd
sudo systemctl daemon-reload
```

#### 删除数据库 (可选)

```bash
sudo mariadb -u root -p
```

```sql
DROP DATABASE ezpanel;
DROP USER 'ezpanel'@'localhost';
FLUSH PRIVILEGES;
EXIT;
```

---

## 故障排除

### 服务无法启动

```bash
# 查看详细日志
sudo journalctl -u ezpanel -n 100 --no-pager

# 检查配置文件语法
ezpanel --check-config

# 检查端口占用
sudo netstat -tlnp | grep 7088
sudo ss -tlnp | grep 7088
```

### 数据库连接失败

**症状**: 日志显示 `failed to connect to database`

**解决方案**:

```bash
# 1. 检查 MariaDB 是否运行
sudo systemctl status mariadb

# 2. 测试数据库连接
mariadb -h localhost -u ezpanel -p ezpanel

# 3. 检查用户权限
sudo mariadb -u root -p
```

```sql
SHOW GRANTS FOR 'ezpanel'@'localhost';
-- 如果没有权限，重新授权
GRANT ALL PRIVILEGES ON ezpanel.* TO 'ezpanel'@'localhost';
FLUSH PRIVILEGES;
```

### Redis/Valkey 连接失败

**症状**: 日志显示 `redis connection failed`

**解决方案**:

```bash
# Arch Linux (Valkey)
sudo systemctl status valkey
sudo systemctl start valkey

# Debian/Ubuntu (Redis)
sudo systemctl status redis-server
sudo systemctl start redis-server

# 测试连接
redis-cli ping
# 应返回 PONG
```

> **注意**: Redis/Valkey 是可选的，系统可以在没有缓存的情况下运行。

### 无法访问面板

**检查清单**:

```bash
# 1. 检查服务状态
sudo systemctl status ezpanel

# 2. 检查端口监听
sudo netstat -tlnp | grep 7088

# 3. 检查防火墙
# Debian/Ubuntu (ufw)
sudo ufw status
sudo ufw allow 7088/tcp

# CentOS/RHEL (firewalld)
sudo firewall-cmd --list-ports
sudo firewall-cmd --add-port=7088/tcp --permanent
sudo firewall-cmd --reload

# Arch Linux (iptables)
sudo iptables -L -n | grep 7088
sudo iptables -A INPUT -p tcp --dport 7088 -j ACCEPT

# 4. 检查 SELinux (CentOS/RHEL)
sudo getenforce
# 如果是 Enforcing，可能需要配置策略
sudo setenforce 0  # 临时禁用测试
```

### 首次登录问题

**默认管理员账号**:
- 邮箱: `admin@opine.work`
- 密码: `admin123`

如果忘记密码，可在数据库中重置：

```bash
sudo mariadb -u root -p
```

```sql
USE ezpanel;

-- 重置为 admin123
UPDATE users
SET password = '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy'
WHERE email = 'admin@opine.work';
```

### 性能问题

**优化建议**:

1. **启用 Redis/Valkey 缓存**
2. **调整数据库连接池**:
   ```yaml
   database:
     max_idle_conns: 20
     max_open_conns: 200
   ```
3. **降低日志级别**:
   ```yaml
   log:
     level: "warn"  # 或 "error"
   ```
4. **使用 Nginx 反向代理**并启用缓存

### 查看详细日志

```bash
# 实时查看日志
sudo journalctl -u ezpanel -f

# 查看最近 100 行
sudo journalctl -u ezpanel -n 100

# 查看特定时间段
sudo journalctl -u ezpanel --since "1 hour ago"

# 开启 debug 日志
sudo vim /etc/ezpanel/config.yaml
# 修改 log.level: "debug"
sudo systemctl restart ezpanel
```

---

## 商业版安装

安装商业版 (Pro/Enterprise) 只需额外安装 `ezpanel-pro` 包：

```bash
# Arch Linux
sudo pacman -U ezpanel-pro-*.pkg.tar.zst

# Debian/Ubuntu
sudo dpkg -i ezpanel-pro_*.deb
```

然后在配置文件中添加：

```yaml
commercial:
  pro_binary_path: "/usr/bin/ezpanel-pro"
  license_path: "/etc/ezpanel/license.json"
  socket_path: "/run/ezpanel/commercial.sock"
```

重启服务即可启用商业功能。

---

## 技术支持

- **GitHub Issues**: https://github.com/opinework/ezpanel/issues
- **文档**: https://github.com/opinework/ezpanel
- **邮件**: support@opine.work

---

**祝您使用愉快！** 🎉
