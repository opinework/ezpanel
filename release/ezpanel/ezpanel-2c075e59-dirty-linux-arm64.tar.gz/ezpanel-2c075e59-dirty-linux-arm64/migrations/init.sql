-- ============================================================================
-- EzPanel Database Schema - Complete Initialization Script
-- Version: 2.0.0
-- Description: 完整的数据库初始化脚本，包含所有表结构、索引和初始数据
-- ============================================================================

SET NAMES utf8mb4;
SET CHARACTER SET utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ============================================================================
-- 用户模块 (user_*)
-- ============================================================================

-- 用户表
DROP TABLE IF EXISTS `user_users`;
CREATE TABLE `user_users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `created_at` datetime(3) DEFAULT CURRENT_TIMESTAMP(3),
  `updated_at` datetime(3) DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  `deleted_at` datetime(3) DEFAULT NULL,
  `email` varchar(255) NOT NULL COMMENT '邮箱',
  `password` varchar(255) NOT NULL COMMENT '密码',
  `uuid` varchar(36) NOT NULL COMMENT '用户UUID，用于订阅',
  `balance` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '余额',
  `commission_balance` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '佣金余额',
  `discount` int NOT NULL DEFAULT '0' COMMENT '专属折扣',
  `is_admin` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否管理员',
  `is_staff` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否员工',
  `role_id` bigint unsigned DEFAULT NULL COMMENT '管理员角色ID',
  `banned` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否封禁',
  `ban_reason` varchar(255) DEFAULT NULL COMMENT '封禁原因',
  `group_id` bigint unsigned NOT NULL DEFAULT '1' COMMENT '用户组ID',
  `last_login_at` datetime DEFAULT NULL COMMENT '最后登录时间',
  `last_login_ip` varchar(45) DEFAULT NULL COMMENT '最后登录IP',
  `invite_user_id` bigint unsigned DEFAULT NULL COMMENT '邀请人ID',
  `telegram_id` bigint DEFAULT NULL COMMENT 'Telegram ID',
  `avatar` varchar(255) DEFAULT NULL COMMENT '头像',
  `remarks` varchar(255) DEFAULT NULL COMMENT '备注',
  `invite_code` varchar(8) NOT NULL COMMENT '邀请码',
  `two_factor_enabled` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否启用两步验证',
  `two_factor_secret` varchar(64) DEFAULT NULL COMMENT '两步验证密钥',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_user_users_email` (`email`),
  UNIQUE KEY `idx_user_users_uuid` (`uuid`),
  UNIQUE KEY `idx_user_users_invite_code` (`invite_code`),
  KEY `idx_user_users_deleted_at` (`deleted_at`),
  KEY `idx_user_users_is_admin` (`is_admin`),
  KEY `idx_user_users_role_id` (`role_id`),
  KEY `idx_user_users_banned` (`banned`),
  KEY `idx_user_users_group_id` (`group_id`),
  KEY `idx_user_users_invite_user_id` (`invite_user_id`),
  KEY `idx_user_users_telegram_id` (`telegram_id`),
  -- 复合索引优化
  KEY `idx_users_banned_created` (`banned`, `created_at` DESC),
  KEY `idx_users_invite_created` (`invite_user_id`, `created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='用户表';

-- 用户登录日志表
DROP TABLE IF EXISTS `user_login_logs`;
CREATE TABLE `user_login_logs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `ip` varchar(45) NOT NULL,
  `user_agent` varchar(512) DEFAULT NULL,
  `country` varchar(100) DEFAULT NULL COMMENT '国家',
  `region` varchar(100) DEFAULT NULL COMMENT '地区',
  `city` varchar(100) DEFAULT NULL COMMENT '城市',
  `created_at` datetime(3) DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  KEY `idx_user_login_logs_user_id` (`user_id`),
  KEY `idx_login_logs_user_created` (`user_id`, `created_at` DESC)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='登录日志';

-- 用户设备表
DROP TABLE IF EXISTS `user_devices`;
CREATE TABLE `user_devices` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `device_id` varchar(64) NOT NULL COMMENT '设备唯一ID',
  `device_name` varchar(100) DEFAULT NULL COMMENT '设备名称',
  `device_type` varchar(50) DEFAULT NULL COMMENT '设备类型: desktop, mobile, tablet',
  `browser` varchar(100) DEFAULT NULL COMMENT '浏览器',
  `os` varchar(100) DEFAULT NULL COMMENT '操作系统',
  `ip` varchar(45) DEFAULT NULL COMMENT 'IP地址',
  `token` varchar(512) DEFAULT NULL COMMENT '关联的JWT Token',
  `last_active_at` datetime DEFAULT NULL COMMENT '最后活跃时间',
  `created_at` datetime(3) DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_user_devices_device_id` (`device_id`),
  KEY `idx_user_devices_user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='用户设备';

-- 用户标签表
DROP TABLE IF EXISTS `user_tags`;
CREATE TABLE `user_tags` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL COMMENT '标签名称',
  `color` varchar(20) NOT NULL DEFAULT '#409EFF' COMMENT '标签颜色',
  `created_at` datetime(3) DEFAULT CURRENT_TIMESTAMP(3),
  `updated_at` datetime(3) DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_user_tags_name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='用户标签';

-- 用户标签关联表
DROP TABLE IF EXISTS `user_tag_mappings`;
CREATE TABLE `user_tag_mappings` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `tag_id` bigint unsigned NOT NULL,
  `created_at` datetime(3) DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  KEY `idx_user_tag_mappings_user_id` (`user_id`),
  KEY `idx_user_tag_mappings_tag_id` (`tag_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='用户标签关联';

-- 账号删除申请表
DROP TABLE IF EXISTS `user_account_deletions`;
CREATE TABLE `user_account_deletions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL COMMENT '用户ID',
  `reason` varchar(500) DEFAULT NULL COMMENT '删除原因',
  `status` tinyint NOT NULL DEFAULT '0' COMMENT '状态: 0=待审核, 1=已通过, 2=已拒绝',
  `admin_note` varchar(255) DEFAULT NULL COMMENT '管理员备注',
  `reviewed_at` datetime DEFAULT NULL COMMENT '审核时间',
  `reviewed_by` bigint unsigned DEFAULT NULL COMMENT '审核人ID',
  `created_at` datetime(3) DEFAULT CURRENT_TIMESTAMP(3),
  `updated_at` datetime(3) DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_user_account_deletions_user_id` (`user_id`),
  KEY `idx_user_account_deletions_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='账号删除申请';

-- ============================================================================
-- 订单模块 (order_*)
-- ============================================================================

-- 套餐表
DROP TABLE IF EXISTS `order_plans`;
CREATE TABLE `order_plans` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `created_at` datetime(3) DEFAULT CURRENT_TIMESTAMP(3),
  `updated_at` datetime(3) DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  `deleted_at` datetime(3) DEFAULT NULL,
  `name` varchar(100) NOT NULL COMMENT '套餐名称',
  `description` text COMMENT '套餐描述',
  `content` text COMMENT '套餐详情(HTML)',
  `group_id` bigint unsigned NOT NULL DEFAULT '0' COMMENT '权限组ID',
  `transfer_enable` bigint NOT NULL DEFAULT '0' COMMENT '流量(字节)',
  `device_limit` int NOT NULL DEFAULT '0' COMMENT '设备限制,0不限',
  `speed_limit` int NOT NULL DEFAULT '0' COMMENT '速度限制(Mbps),0不限',
  `monthly_price` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '月付价格',
  `quarterly_price` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '季付价格',
  `half_yearly_price` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '半年付价格',
  `yearly_price` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '年付价格',
  `two_year_price` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '两年付价格',
  `three_year_price` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '三年付价格',
  `onetime_price` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '一次性价格',
  `reset_price` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '重置流量价格',
  `capacity_limit` int NOT NULL DEFAULT '0' COMMENT '销量限制,0不限',
  `sold_count` int NOT NULL DEFAULT '0' COMMENT '已售数量',
  `renew` tinyint(1) NOT NULL DEFAULT '1' COMMENT '允许续费',
  `sell` tinyint(1) NOT NULL DEFAULT '1' COMMENT '允许购买',
  `reset_traffic_method` tinyint NOT NULL DEFAULT '0' COMMENT '流量重置方式:0月初,1按月,2不重置',
  `sort` int NOT NULL DEFAULT '0' COMMENT '排序',
  `show` tinyint(1) NOT NULL DEFAULT '1' COMMENT '是否显示',
  PRIMARY KEY (`id`),
  KEY `idx_order_plans_deleted_at` (`deleted_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='套餐表';

-- 订单表
DROP TABLE IF EXISTS `order_orders`;
CREATE TABLE `order_orders` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `created_at` datetime(3) DEFAULT CURRENT_TIMESTAMP(3),
  `updated_at` datetime(3) DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  `deleted_at` datetime(3) DEFAULT NULL,
  `user_id` bigint unsigned NOT NULL COMMENT '用户ID',
  `trade_no` varchar(32) NOT NULL COMMENT '订单号',
  `callback_no` varchar(64) DEFAULT NULL COMMENT '支付平台订单号',
  `plan_id` bigint unsigned NOT NULL COMMENT '套餐ID',
  `period` varchar(20) NOT NULL COMMENT '周期',
  `type` tinyint NOT NULL DEFAULT '1' COMMENT '类型:1新购,2续费,3升级,4流量重置',
  `total_amount` decimal(10,2) NOT NULL COMMENT '原价',
  `discount_amount` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '折扣金额',
  `paid_amount` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '实付金额',
  `balance_amount` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '余额支付金额',
  `coupon_id` bigint unsigned DEFAULT NULL COMMENT '优惠券ID',
  `coupon_code` varchar(50) DEFAULT NULL COMMENT '优惠码',
  `payment_id` bigint unsigned DEFAULT NULL COMMENT '支付方式ID',
  `status` tinyint NOT NULL DEFAULT '0' COMMENT '状态:0待支付,1已支付,2已取消,3已退款',
  `paid_at` datetime DEFAULT NULL COMMENT '支付时间',
  `expired_at` datetime DEFAULT NULL COMMENT '订阅到期时间',
  `invite_user_id` bigint unsigned DEFAULT NULL COMMENT '邀请人ID',
  `commission` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '佣金金额',
  `commission_status` tinyint NOT NULL DEFAULT '0' COMMENT '佣金状态: 0未结算, 1已结算',
  `transfer_enable` bigint NOT NULL DEFAULT '0' COMMENT '总流量(字节)',
  `upload` bigint NOT NULL DEFAULT '0' COMMENT '已上传流量(字节)',
  `download` bigint NOT NULL DEFAULT '0' COMMENT '已下载流量(字节)',
  `traffic_reset_day` int NOT NULL DEFAULT '0' COMMENT '流量重置日',
  `last_traffic_reset_at` datetime DEFAULT NULL COMMENT '上次流量重置时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_order_orders_trade_no` (`trade_no`),
  KEY `idx_order_orders_deleted_at` (`deleted_at`),
  KEY `idx_order_orders_user_id` (`user_id`),
  KEY `idx_order_orders_plan_id` (`plan_id`),
  KEY `idx_order_orders_status` (`status`),
  KEY `idx_order_orders_type` (`type`),
  KEY `idx_order_orders_coupon_id` (`coupon_id`),
  KEY `idx_order_orders_payment_id` (`payment_id`),
  KEY `idx_order_orders_paid_at` (`paid_at`),
  KEY `idx_order_orders_expired_at` (`expired_at`),
  KEY `idx_order_orders_invite_user_id` (`invite_user_id`),
  KEY `idx_order_orders_commission_status` (`commission_status`),
  KEY `idx_order_orders_callback_no` (`callback_no`),
  -- 复合索引优化
  KEY `idx_orders_status_created` (`status`, `created_at` DESC),
  KEY `idx_orders_user_status` (`user_id`, `status`),
  KEY `idx_orders_trade_status` (`callback_no`, `status`),
  KEY `idx_orders_paid_at_status` (`paid_at`, `status`),
  KEY `idx_orders_commission_status_invite` (`commission_status`, `invite_user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='订单表';

-- ============================================================================
-- 节点模块 (node_*)
-- ============================================================================

-- 节点组表
DROP TABLE IF EXISTS `node_server_groups`;
CREATE TABLE `node_server_groups` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL COMMENT '组名',
  `created_at` datetime(3) DEFAULT CURRENT_TIMESTAMP(3),
  `updated_at` datetime(3) DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='节点组';

-- 节点表
DROP TABLE IF EXISTS `node_servers`;
CREATE TABLE `node_servers` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `created_at` datetime(3) DEFAULT CURRENT_TIMESTAMP(3),
  `updated_at` datetime(3) DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  `deleted_at` datetime(3) DEFAULT NULL,
  `name` varchar(100) NOT NULL COMMENT '节点名称',
  `group_ids` json DEFAULT NULL COMMENT '所属组ID数组',
  `parent_id` bigint unsigned NOT NULL DEFAULT '0' COMMENT '父节点ID',
  `host` varchar(255) NOT NULL COMMENT '服务器地址',
  `port` int NOT NULL COMMENT '端口',
  `server_port` int NOT NULL DEFAULT '0' COMMENT '服务端口',
  `tags` json DEFAULT NULL COMMENT '标签',
  `rate` decimal(5,2) NOT NULL DEFAULT '1.00' COMMENT '倍率',
  `speed_limit` int NOT NULL DEFAULT '0' COMMENT '限速(Mbps)',
  `sort` int NOT NULL DEFAULT '0' COMMENT '排序',
  `show` tinyint(1) NOT NULL DEFAULT '1' COMMENT '是否显示',
  `status` tinyint NOT NULL DEFAULT '0' COMMENT '状态:0离线,1在线,2维护',
  `online_count` int NOT NULL DEFAULT '0' COMMENT '在线人数',
  `last_check_at` datetime DEFAULT NULL COMMENT '最后检查时间',
  `last_push_at` datetime DEFAULT NULL COMMENT '最后推送时间',
  `last_client_type` varchar(20) DEFAULT NULL COMMENT '最后连接的客户端类型',
  `ssh_host` varchar(255) DEFAULT NULL COMMENT 'SSH主机地址',
  `ssh_port` int NOT NULL DEFAULT '22' COMMENT 'SSH端口',
  `ssh_user` varchar(64) DEFAULT NULL COMMENT 'SSH用户名',
  `ssh_password` varchar(255) DEFAULT NULL COMMENT 'SSH密码(加密)',
  `ssh_public_key` text COMMENT 'SSH公钥',
  `ssh_private_key` text COMMENT 'SSH私钥',
  `xrayr_config_path` varchar(255) DEFAULT NULL COMMENT 'XrayR配置路径',
  `xrayr_package` varchar(255) DEFAULT NULL COMMENT 'XrayR安装包',
  `xrayr_node_id` varchar(50) DEFAULT NULL COMMENT 'XrayR节点ID',
  PRIMARY KEY (`id`),
  KEY `idx_node_servers_deleted_at` (`deleted_at`),
  KEY `idx_node_servers_parent_id` (`parent_id`),
  KEY `idx_node_servers_sort` (`sort`),
  KEY `idx_node_servers_show` (`show`),
  KEY `idx_node_servers_status` (`status`),
  -- 复合索引优化
  KEY `idx_servers_show_sort` (`show`, `sort`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='节点表';

-- 节点协议配置表
DROP TABLE IF EXISTS `node_server_protocols`;
CREATE TABLE `node_server_protocols` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `created_at` datetime(3) DEFAULT CURRENT_TIMESTAMP(3),
  `updated_at` datetime(3) DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  `deleted_at` datetime(3) DEFAULT NULL,
  `server_id` bigint unsigned NOT NULL COMMENT '节点ID',
  `name` varchar(100) DEFAULT '' COMMENT '自定义名称',
  `host` varchar(255) NOT NULL COMMENT '连接地址',
  `port` int NOT NULL COMMENT '连接端口',
  `protocol` varchar(20) NOT NULL COMMENT '协议类型: vmess, vless, trojan, shadowsocks, hysteria2, tuic',
  `server_port` int NOT NULL COMMENT '服务端口',
  `transport` varchar(20) NOT NULL DEFAULT 'tcp' COMMENT '传输方式',
  `transport_settings` longtext COMMENT '传输配置',
  `tls` tinyint NOT NULL DEFAULT '0' COMMENT 'TLS类型: 0=无, 1=TLS, 2=Reality',
  `tls_settings` longtext COMMENT 'TLS配置',
  `protocol_settings` longtext COMMENT '协议专用配置',
  `enabled` tinyint(1) NOT NULL DEFAULT '1' COMMENT '是否启用',
  `sort` int NOT NULL DEFAULT '0' COMMENT '排序',
  PRIMARY KEY (`id`),
  KEY `idx_node_server_protocols_deleted_at` (`deleted_at`),
  KEY `idx_node_server_protocols_server_id` (`server_id`),
  KEY `idx_node_server_protocols_protocol` (`protocol`),
  KEY `idx_node_server_protocols_enabled` (`enabled`),
  KEY `idx_node_server_protocols_host` (`host`),
  CONSTRAINT `fk_server_protocols_server` FOREIGN KEY (`server_id`) REFERENCES `node_servers` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='节点协议配置';

-- 流量日志表
DROP TABLE IF EXISTS `node_traffic_logs`;
CREATE TABLE `node_traffic_logs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `server_id` bigint unsigned NOT NULL,
  `upload` bigint NOT NULL DEFAULT '0' COMMENT '上传流量(字节)',
  `download` bigint NOT NULL DEFAULT '0' COMMENT '下载流量(字节)',
  `log_at` datetime NOT NULL COMMENT '记录时间',
  `created_at` datetime(3) DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  KEY `idx_node_traffic_logs_user_id` (`user_id`),
  KEY `idx_node_traffic_logs_server_id` (`server_id`),
  KEY `idx_node_traffic_logs_log_at` (`log_at`),
  -- 复合索引优化
  KEY `idx_traffic_user_logat` (`user_id`, `log_at`),
  KEY `idx_traffic_server_logat` (`server_id`, `log_at`),
  KEY `idx_traffic_logat_user` (`log_at`, `user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='流量日志';

-- 节点监控历史记录表
DROP TABLE IF EXISTS `node_metrics_logs`;
CREATE TABLE `node_metrics_logs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `server_id` bigint unsigned NOT NULL COMMENT '节点ID',
  `cpu_percent` decimal(5,2) DEFAULT NULL COMMENT 'CPU使用率',
  `memory_percent` decimal(5,2) DEFAULT NULL COMMENT '内存使用率',
  `disk_percent` decimal(5,2) DEFAULT NULL COMMENT '磁盘使用率',
  `load1` decimal(8,2) DEFAULT NULL COMMENT '1分钟负载',
  `load5` decimal(8,2) DEFAULT NULL COMMENT '5分钟负载',
  `load15` decimal(8,2) DEFAULT NULL COMMENT '15分钟负载',
  `net_rx` bigint DEFAULT NULL COMMENT '网络接收',
  `net_tx` bigint DEFAULT NULL COMMENT '网络发送',
  `created_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  KEY `idx_metrics_server_time` (`server_id`, `created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='节点监控历史';

-- 节点违规日志表
DROP TABLE IF EXISTS `node_illegal_logs`;
CREATE TABLE `node_illegal_logs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `server_id` bigint unsigned NOT NULL COMMENT '节点ID',
  `user_id` bigint unsigned NOT NULL COMMENT '用户ID',
  `rule_id` int DEFAULT NULL COMMENT '规则ID',
  `created_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  KEY `idx_node_illegal_logs_server_id` (`server_id`),
  KEY `idx_node_illegal_logs_user_id` (`user_id`),
  KEY `idx_node_illegal_logs_rule_id` (`rule_id`),
  KEY `idx_node_illegal_logs_created_at` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='节点违规日志';

-- ============================================================================
-- 促销模块 (promo_*)
-- ============================================================================

-- 优惠券表
DROP TABLE IF EXISTS `promo_coupons`;
CREATE TABLE `promo_coupons` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `created_at` datetime(3) DEFAULT CURRENT_TIMESTAMP(3),
  `updated_at` datetime(3) DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  `deleted_at` datetime(3) DEFAULT NULL,
  `code` varchar(50) NOT NULL COMMENT '优惠码',
  `name` varchar(100) NOT NULL COMMENT '优惠券名称',
  `type` tinyint NOT NULL DEFAULT '1' COMMENT '类型:1固定金额,2百分比',
  `value` decimal(10,2) NOT NULL COMMENT '优惠值',
  `limit_use` int NOT NULL DEFAULT '0' COMMENT '总使用次数限制,0不限',
  `limit_use_with_user` int NOT NULL DEFAULT '1' COMMENT '每用户限制次数',
  `limit_plan_ids` json DEFAULT NULL COMMENT '限制套餐ID',
  `limit_period` json DEFAULT NULL COMMENT '限制周期',
  `used_count` int NOT NULL DEFAULT '0' COMMENT '已使用次数',
  `started_at` datetime DEFAULT NULL COMMENT '开始时间',
  `ended_at` datetime DEFAULT NULL COMMENT '结束时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_promo_coupons_code` (`code`),
  KEY `idx_promo_coupons_deleted_at` (`deleted_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='优惠券表';

-- 优惠券使用记录表
DROP TABLE IF EXISTS `promo_coupon_usages`;
CREATE TABLE `promo_coupon_usages` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `coupon_id` bigint unsigned NOT NULL,
  `user_id` bigint unsigned NOT NULL,
  `order_id` bigint unsigned NOT NULL,
  `created_at` datetime(3) DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  KEY `idx_promo_coupon_usages_coupon_id` (`coupon_id`),
  KEY `idx_promo_coupon_usages_user_id` (`user_id`),
  -- 复合索引优化
  KEY `idx_coupon_usage_user_coupon` (`user_id`, `coupon_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='优惠券使用记录';

-- 卡密表
DROP TABLE IF EXISTS `promo_redeem_codes`;
CREATE TABLE `promo_redeem_codes` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(50) NOT NULL COMMENT '卡密',
  `type` tinyint NOT NULL COMMENT '类型:1套餐,2余额,3流量',
  `value` bigint NOT NULL COMMENT '值',
  `plan_id` bigint unsigned DEFAULT NULL COMMENT '套餐ID(type=1时)',
  `period` varchar(20) DEFAULT NULL COMMENT '周期(type=1时)',
  `used_user_id` bigint unsigned DEFAULT NULL COMMENT '使用者ID',
  `used_at` datetime DEFAULT NULL COMMENT '使用时间',
  `expired_at` datetime DEFAULT NULL COMMENT '过期时间',
  `created_at` datetime(3) DEFAULT CURRENT_TIMESTAMP(3),
  `updated_at` datetime(3) DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_promo_redeem_codes_code` (`code`),
  KEY `idx_redeem_type_used` (`type`, `used_user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='卡密表';

-- 邀请记录表
DROP TABLE IF EXISTS `promo_invite_records`;
CREATE TABLE `promo_invite_records` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `inviter_id` bigint unsigned NOT NULL COMMENT '邀请人ID',
  `user_id` bigint unsigned NOT NULL COMMENT '被邀请人ID',
  `commission_rate` decimal(5,2) NOT NULL DEFAULT '0.00' COMMENT '佣金比例',
  `created_at` datetime(3) DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  KEY `idx_promo_invite_records_inviter_id` (`inviter_id`),
  KEY `idx_promo_invite_records_user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='邀请记录';

-- 营销活动表
DROP TABLE IF EXISTS `promo_campaigns`;
CREATE TABLE `promo_campaigns` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `created_at` datetime(3) DEFAULT CURRENT_TIMESTAMP(3),
  `updated_at` datetime(3) DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  `deleted_at` datetime(3) DEFAULT NULL,
  `name` varchar(100) NOT NULL COMMENT '活动名称',
  `code` varchar(50) DEFAULT NULL COMMENT '活动代码',
  `type` varchar(50) DEFAULT NULL COMMENT '活动类型',
  `description` text COMMENT '活动描述',
  `rules` json DEFAULT NULL COMMENT '活动规则',
  `start_at` datetime DEFAULT NULL COMMENT '开始时间',
  `end_at` datetime DEFAULT NULL COMMENT '结束时间',
  `priority` int NOT NULL DEFAULT '0' COMMENT '优先级',
  `enabled` tinyint(1) NOT NULL DEFAULT '1' COMMENT '是否启用',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_promo_campaigns_code` (`code`),
  KEY `idx_promo_campaigns_deleted_at` (`deleted_at`),
  KEY `idx_promo_campaigns_enabled` (`enabled`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='营销活动';

-- 活动使用记录表
DROP TABLE IF EXISTS `promo_campaign_usages`;
CREATE TABLE `promo_campaign_usages` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `campaign_id` bigint unsigned NOT NULL,
  `user_id` bigint unsigned NOT NULL,
  `order_id` bigint unsigned NOT NULL,
  `discount` decimal(10,2) DEFAULT NULL COMMENT '折扣金额',
  `created_at` datetime(3) DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  KEY `idx_promo_campaign_usages_campaign_id` (`campaign_id`),
  KEY `idx_promo_campaign_usages_user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='活动使用记录';

-- ============================================================================
-- 财务模块 (fin_*)
-- ============================================================================

-- 支付方式表
DROP TABLE IF EXISTS `fin_payments`;
CREATE TABLE `fin_payments` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL COMMENT '支付名称',
  `icon` varchar(255) DEFAULT NULL COMMENT '图标',
  `payment` varchar(50) NOT NULL COMMENT '支付类型',
  `config` json NOT NULL COMMENT '支付配置',
  `handling_fee_fixed` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '固定手续费',
  `handling_fee_percent` decimal(5,2) NOT NULL DEFAULT '0.00' COMMENT '百分比手续费',
  `sort` int NOT NULL DEFAULT '0' COMMENT '排序',
  `enable` tinyint(1) NOT NULL DEFAULT '1' COMMENT '是否启用',
  `created_at` datetime(3) DEFAULT CURRENT_TIMESTAMP(3),
  `updated_at` datetime(3) DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='支付方式';

-- 佣金记录表
DROP TABLE IF EXISTS `fin_commission_logs`;
CREATE TABLE `fin_commission_logs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL COMMENT '获得佣金用户ID',
  `from_user_id` bigint unsigned NOT NULL COMMENT '来源用户ID',
  `order_id` bigint unsigned NOT NULL COMMENT '订单ID',
  `get_amount` decimal(10,2) NOT NULL COMMENT '佣金金额',
  `status` tinyint NOT NULL DEFAULT '0' COMMENT '状态: 0=待确认, 1=已确认, 2=已拒绝',
  `confirmed_at` datetime DEFAULT NULL COMMENT '确认时间',
  `created_at` datetime(3) DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  KEY `idx_fin_commission_logs_user_id` (`user_id`),
  KEY `idx_fin_commission_logs_from_user_id` (`from_user_id`),
  KEY `idx_fin_commission_logs_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='佣金记录';

-- 统计数据表
DROP TABLE IF EXISTS `fin_statistics`;
CREATE TABLE `fin_statistics` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `record_at` datetime NOT NULL COMMENT '统计日期',
  `new_users` int NOT NULL DEFAULT '0' COMMENT '新增用户',
  `new_orders` int NOT NULL DEFAULT '0' COMMENT '新增订单',
  `paid_orders` int NOT NULL DEFAULT '0' COMMENT '已支付订单',
  `total_income` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '总收入',
  `total_commission` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '总佣金',
  `online_users` int NOT NULL DEFAULT '0' COMMENT '在线用户',
  `created_at` datetime(3) DEFAULT CURRENT_TIMESTAMP(3),
  `updated_at` datetime(3) DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_fin_statistics_record_at` (`record_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='统计数据';

-- 提现申请表
DROP TABLE IF EXISTS `fin_withdrawals`;
CREATE TABLE `fin_withdrawals` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL COMMENT '用户ID',
  `amount` decimal(10,2) NOT NULL COMMENT '提现金额',
  `fee` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '手续费',
  `actual_amount` decimal(10,2) NOT NULL COMMENT '实际到账',
  `address` varchar(64) NOT NULL COMMENT '钱包地址',
  `status` tinyint NOT NULL DEFAULT '0' COMMENT '状态: 0=待审核, 1=已通过, 2=已打款, 3=已拒绝',
  `tx_hash` varchar(128) DEFAULT NULL COMMENT '交易哈希',
  `admin_note` varchar(255) DEFAULT NULL COMMENT '管理员备注',
  `reviewed_at` datetime DEFAULT NULL COMMENT '审核时间',
  `completed_at` datetime DEFAULT NULL COMMENT '完成时间',
  `created_at` datetime(3) DEFAULT CURRENT_TIMESTAMP(3),
  `updated_at` datetime(3) DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  KEY `idx_fin_withdrawals_user_id` (`user_id`),
  KEY `idx_fin_withdrawals_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='提现申请';

-- 发票表
DROP TABLE IF EXISTS `fin_invoices`;
CREATE TABLE `fin_invoices` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `created_at` datetime(3) DEFAULT CURRENT_TIMESTAMP(3),
  `updated_at` datetime(3) DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  `deleted_at` datetime(3) DEFAULT NULL,
  `invoice_no` varchar(32) NOT NULL COMMENT '发票编号',
  `order_id` bigint unsigned NOT NULL COMMENT '订单ID',
  `user_id` bigint unsigned NOT NULL COMMENT '用户ID',
  `type` tinyint NOT NULL DEFAULT '1' COMMENT '发票类型',
  `title_type` tinyint NOT NULL DEFAULT '1' COMMENT '抬头类型: 1=个人, 2=企业',
  `title` varchar(255) NOT NULL COMMENT '发票抬头',
  `tax_no` varchar(50) DEFAULT NULL COMMENT '纳税人识别号',
  `email` varchar(100) DEFAULT NULL COMMENT '接收邮箱',
  `amount` decimal(10,2) NOT NULL COMMENT '发票金额',
  `status` tinyint NOT NULL DEFAULT '0' COMMENT '状态: 0=待开具, 1=已开具, 2=已拒绝',
  `rejected_reason` varchar(255) DEFAULT NULL COMMENT '拒绝原因',
  `issued_at` datetime DEFAULT NULL COMMENT '开具时间',
  `download_url` varchar(512) DEFAULT NULL COMMENT '下载链接',
  `admin_note` varchar(255) DEFAULT NULL COMMENT '管理员备注',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_fin_invoices_invoice_no` (`invoice_no`),
  KEY `idx_fin_invoices_deleted_at` (`deleted_at`),
  KEY `idx_fin_invoices_order_id` (`order_id`),
  KEY `idx_fin_invoices_user_id` (`user_id`),
  KEY `idx_fin_invoices_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='发票';

-- ============================================================================
-- 客服支持模块 (support_*)
-- ============================================================================

-- 工单表
DROP TABLE IF EXISTS `support_tickets`;
CREATE TABLE `support_tickets` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `subject` varchar(255) NOT NULL COMMENT '主题',
  `level` tinyint NOT NULL DEFAULT '1' COMMENT '优先级:1低,2中,3高',
  `status` tinyint NOT NULL DEFAULT '0' COMMENT '状态:0待处理,1处理中,2已关闭',
  `category` varchar(50) DEFAULT NULL COMMENT '工单分类',
  `assigned_to` bigint unsigned DEFAULT NULL COMMENT '指派给的管理员ID',
  `due_at` datetime DEFAULT NULL COMMENT 'SLA截止时间',
  `created_at` datetime(3) DEFAULT CURRENT_TIMESTAMP(3),
  `updated_at` datetime(3) DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  KEY `idx_support_tickets_user_id` (`user_id`),
  KEY `idx_support_tickets_status` (`status`),
  KEY `idx_support_tickets_category` (`category`),
  KEY `idx_support_tickets_assigned_to` (`assigned_to`),
  -- 复合索引优化
  KEY `idx_tickets_status_updated` (`status`, `updated_at` DESC),
  KEY `idx_tickets_user_status` (`user_id`, `status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='工单表';

-- 工单消息表
DROP TABLE IF EXISTS `support_ticket_messages`;
CREATE TABLE `support_ticket_messages` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `ticket_id` bigint unsigned NOT NULL,
  `user_id` bigint unsigned NOT NULL COMMENT '发送者ID',
  `is_admin` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否管理员回复',
  `content` text NOT NULL COMMENT '消息内容',
  `created_at` datetime(3) DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  KEY `idx_support_ticket_messages_ticket_id` (`ticket_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='工单消息';

-- 公告表
DROP TABLE IF EXISTS `support_announcements`;
CREATE TABLE `support_announcements` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL COMMENT '标题',
  `content` text NOT NULL COMMENT '内容',
  `img_url` varchar(255) DEFAULT NULL COMMENT '图片URL',
  `tags` json DEFAULT NULL COMMENT '标签',
  `show` tinyint(1) NOT NULL DEFAULT '1' COMMENT '是否显示',
  `pinned` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否置顶',
  `sort` int NOT NULL DEFAULT '0' COMMENT '排序',
  `created_at` datetime(3) DEFAULT CURRENT_TIMESTAMP(3),
  `updated_at` datetime(3) DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  KEY `idx_support_announcements_show` (`show`),
  KEY `idx_support_announcements_pinned` (`pinned`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='公告表';

-- 知识库分类表
DROP TABLE IF EXISTS `support_knowledge_categories`;
CREATE TABLE `support_knowledge_categories` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL COMMENT '分类名称',
  `created_at` datetime(3) DEFAULT CURRENT_TIMESTAMP(3),
  `updated_at` datetime(3) DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='知识库分类';

-- 知识库表
DROP TABLE IF EXISTS `support_knowledge`;
CREATE TABLE `support_knowledge` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `category_id` bigint unsigned NOT NULL COMMENT '分类ID',
  `title` varchar(255) NOT NULL COMMENT '标题',
  `body` text NOT NULL COMMENT '内容',
  `sort` int NOT NULL DEFAULT '0' COMMENT '排序',
  `show` tinyint(1) NOT NULL DEFAULT '1' COMMENT '是否显示',
  `is_faq` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否为FAQ',
  `view_count` int NOT NULL DEFAULT '0' COMMENT '浏览次数',
  `helpful` int NOT NULL DEFAULT '0' COMMENT '有帮助次数',
  `unhelpful` int NOT NULL DEFAULT '0' COMMENT '无帮助次数',
  `created_at` datetime(3) DEFAULT CURRENT_TIMESTAMP(3),
  `updated_at` datetime(3) DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  KEY `idx_support_knowledge_category_id` (`category_id`),
  KEY `idx_support_knowledge_show` (`show`),
  KEY `idx_support_knowledge_is_faq` (`is_faq`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='知识库';

-- 站内消息表
DROP TABLE IF EXISTS `support_messages`;
CREATE TABLE `support_messages` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `created_at` datetime(3) DEFAULT CURRENT_TIMESTAMP(3),
  `updated_at` datetime(3) DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  `deleted_at` datetime(3) DEFAULT NULL,
  `user_id` bigint unsigned NOT NULL COMMENT '接收用户ID',
  `title` varchar(255) NOT NULL COMMENT '消息标题',
  `content` text NOT NULL COMMENT '消息内容',
  `type` varchar(50) NOT NULL DEFAULT 'system' COMMENT '消息类型',
  `is_read` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否已读',
  `read_at` datetime DEFAULT NULL COMMENT '阅读时间',
  PRIMARY KEY (`id`),
  KEY `idx_support_messages_deleted_at` (`deleted_at`),
  KEY `idx_support_messages_user_id` (`user_id`),
  KEY `idx_support_messages_is_read` (`is_read`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='站内消息';

-- ============================================================================
-- 系统模块 (sys_*)
-- ============================================================================

-- 系统设置表
DROP TABLE IF EXISTS `sys_settings`;
CREATE TABLE `sys_settings` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `key` varchar(100) NOT NULL COMMENT '设置键',
  `value` text COMMENT '设置值',
  `created_at` datetime(3) DEFAULT CURRENT_TIMESTAMP(3),
  `updated_at` datetime(3) DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_sys_settings_key` (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='系统设置';

-- 邮件模板表
DROP TABLE IF EXISTS `sys_email_templates`;
CREATE TABLE `sys_email_templates` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `created_at` datetime(3) DEFAULT CURRENT_TIMESTAMP(3),
  `updated_at` datetime(3) DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  `deleted_at` datetime(3) DEFAULT NULL,
  `code` varchar(50) NOT NULL COMMENT '模板代码',
  `name` varchar(100) NOT NULL COMMENT '模板名称',
  `subject` varchar(255) NOT NULL COMMENT '邮件主题',
  `content` text NOT NULL COMMENT '邮件内容',
  `telegram_content` text COMMENT 'Telegram消息内容',
  `variables` text COMMENT '可用变量说明',
  `description` varchar(255) DEFAULT NULL COMMENT '模板描述',
  `enabled` tinyint(1) NOT NULL DEFAULT '1' COMMENT '是否启用',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_sys_email_templates_code` (`code`),
  KEY `idx_sys_email_templates_deleted_at` (`deleted_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='邮件模板';

-- 审计日志表
DROP TABLE IF EXISTS `sys_audit_logs`;
CREATE TABLE `sys_audit_logs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `admin_id` bigint unsigned NOT NULL COMMENT '管理员ID',
  `action` varchar(50) NOT NULL COMMENT '操作类型',
  `module` varchar(50) NOT NULL COMMENT '模块名称',
  `target_type` varchar(50) DEFAULT NULL COMMENT '目标类型',
  `target_id` bigint unsigned NOT NULL DEFAULT '0' COMMENT '目标ID',
  `detail` text COMMENT '操作详情',
  `ip` varchar(45) DEFAULT NULL COMMENT '操作IP',
  `user_agent` varchar(512) DEFAULT NULL COMMENT '浏览器信息',
  `created_at` datetime(3) DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  KEY `idx_sys_audit_logs_admin_id` (`admin_id`),
  KEY `idx_sys_audit_logs_action` (`action`),
  KEY `idx_sys_audit_logs_module` (`module`),
  KEY `idx_sys_audit_logs_target_id` (`target_id`),
  KEY `idx_sys_audit_logs_created_at` (`created_at`),
  -- 复合索引优化
  KEY `idx_audit_logs_module_created` (`module`, `created_at` DESC),
  KEY `idx_audit_logs_admin_created` (`admin_id`, `created_at` DESC)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='审计日志';

-- 管理员角色表
DROP TABLE IF EXISTS `sys_admin_roles`;
CREATE TABLE `sys_admin_roles` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL COMMENT '角色名称',
  `code` varchar(50) NOT NULL COMMENT '角色代码',
  `description` varchar(255) DEFAULT NULL COMMENT '角色描述',
  `permissions` json DEFAULT NULL COMMENT '权限列表',
  `created_at` datetime(3) DEFAULT CURRENT_TIMESTAMP(3),
  `updated_at` datetime(3) DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_sys_admin_roles_name` (`name`),
  UNIQUE KEY `idx_sys_admin_roles_code` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='管理员角色';

-- 节点告警表
DROP TABLE IF EXISTS `sys_node_alerts`;
CREATE TABLE `sys_node_alerts` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `server_id` bigint unsigned NOT NULL COMMENT '节点ID',
  `alert_type` varchar(50) DEFAULT NULL COMMENT '告警类型',
  `message` text COMMENT '告警消息',
  `notified` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否已通知',
  `created_at` datetime(3) DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  KEY `idx_sys_node_alerts_server_id` (`server_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='节点告警';

-- 客户端下载表
DROP TABLE IF EXISTS `sys_client_downloads`;
CREATE TABLE `sys_client_downloads` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `created_at` datetime(3) DEFAULT CURRENT_TIMESTAMP(3),
  `updated_at` datetime(3) DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  `deleted_at` datetime(3) DEFAULT NULL,
  `name` varchar(100) NOT NULL COMMENT '客户端名称',
  `platform` varchar(50) NOT NULL COMMENT '平台',
  `icon` varchar(255) DEFAULT NULL COMMENT '图标',
  `description` text COMMENT '描述',
  `download_url` varchar(512) DEFAULT NULL COMMENT '下载链接',
  `upload_type` varchar(20) NOT NULL DEFAULT 'link' COMMENT '来源类型: link/upload',
  `file_path` varchar(512) DEFAULT NULL COMMENT '上传文件路径',
  `file_name` varchar(255) DEFAULT NULL COMMENT '原始文件名',
  `file_size` bigint NOT NULL DEFAULT '0' COMMENT '文件大小',
  `version` varchar(20) DEFAULT NULL COMMENT '版本',
  `sort` int NOT NULL DEFAULT '0' COMMENT '排序',
  `show` tinyint(1) NOT NULL DEFAULT '1' COMMENT '是否显示',
  `is_official` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否官方客户端',
  PRIMARY KEY (`id`),
  KEY `idx_sys_client_downloads_deleted_at` (`deleted_at`),
  KEY `idx_sys_client_downloads_platform` (`platform`),
  KEY `idx_sys_client_downloads_show` (`show`),
  KEY `idx_sys_client_downloads_is_official` (`is_official`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='客户端管理';

-- 批量通知任务表
DROP TABLE IF EXISTS `sys_notification_tasks`;
CREATE TABLE `sys_notification_tasks` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `created_at` datetime(3) DEFAULT CURRENT_TIMESTAMP(3),
  `updated_at` datetime(3) DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  `deleted_at` datetime(3) DEFAULT NULL,
  `admin_id` bigint unsigned NOT NULL COMMENT '创建管理员ID',
  `target_type` varchar(20) DEFAULT NULL COMMENT '目标类型',
  `target_count` int NOT NULL DEFAULT '0' COMMENT '目标数量',
  `filter` json DEFAULT NULL COMMENT '筛选条件',
  `channels` json DEFAULT NULL COMMENT '通知渠道',
  `title` varchar(255) DEFAULT NULL COMMENT '通知标题',
  `content` text COMMENT '通知内容',
  `status` tinyint NOT NULL DEFAULT '0' COMMENT '状态',
  `sent_count` int NOT NULL DEFAULT '0' COMMENT '已发送数量',
  `failed_count` int NOT NULL DEFAULT '0' COMMENT '失败数量',
  `scheduled_at` datetime DEFAULT NULL COMMENT '计划发送时间',
  PRIMARY KEY (`id`),
  KEY `idx_sys_notification_tasks_deleted_at` (`deleted_at`),
  KEY `idx_sys_notification_tasks_admin_id` (`admin_id`),
  KEY `idx_sys_notification_tasks_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='批量通知任务';

-- Webhook配置表
DROP TABLE IF EXISTS `sys_webhooks`;
CREATE TABLE `sys_webhooks` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `created_at` datetime(3) DEFAULT CURRENT_TIMESTAMP(3),
  `updated_at` datetime(3) DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  `deleted_at` datetime(3) DEFAULT NULL,
  `name` varchar(100) NOT NULL COMMENT 'Webhook名称',
  `event_type` varchar(50) NOT NULL COMMENT '事件类型',
  `url` varchar(512) NOT NULL COMMENT '回调URL',
  `secret` varchar(64) DEFAULT NULL COMMENT '密钥',
  `enabled` tinyint(1) NOT NULL DEFAULT '1' COMMENT '是否启用',
  `retry` int NOT NULL DEFAULT '3' COMMENT '重试次数',
  `description` varchar(255) DEFAULT NULL COMMENT '描述',
  PRIMARY KEY (`id`),
  KEY `idx_sys_webhooks_deleted_at` (`deleted_at`),
  KEY `idx_sys_webhooks_event_type` (`event_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Webhook配置';

-- Webhook日志表
DROP TABLE IF EXISTS `sys_webhook_logs`;
CREATE TABLE `sys_webhook_logs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `webhook_id` bigint unsigned NOT NULL COMMENT 'Webhook ID',
  `event_type` varchar(50) DEFAULT NULL COMMENT '事件类型',
  `status` tinyint NOT NULL DEFAULT '0' COMMENT '状态',
  `response` text COMMENT '响应内容',
  `error` text COMMENT '错误信息',
  `created_at` datetime(3) DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  KEY `idx_sys_webhook_logs_webhook_id` (`webhook_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Webhook日志';

-- API密钥表
DROP TABLE IF EXISTS `sys_api_keys`;
CREATE TABLE `sys_api_keys` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `created_at` datetime(3) DEFAULT CURRENT_TIMESTAMP(3),
  `updated_at` datetime(3) DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  `deleted_at` datetime(3) DEFAULT NULL,
  `user_id` bigint unsigned NOT NULL COMMENT '用户ID',
  `name` varchar(100) DEFAULT NULL COMMENT '密钥名称',
  `key` varchar(64) NOT NULL COMMENT 'API密钥',
  `key_prefix` varchar(20) DEFAULT NULL COMMENT '密钥前缀',
  `permissions` json DEFAULT NULL COMMENT '权限列表',
  `rate_limit` int NOT NULL DEFAULT '100' COMMENT '频率限制',
  `last_used_at` datetime DEFAULT NULL COMMENT '最后使用时间',
  `expires_at` datetime DEFAULT NULL COMMENT '过期时间',
  `enabled` tinyint(1) NOT NULL DEFAULT '1' COMMENT '是否启用',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_sys_api_keys_key` (`key`),
  KEY `idx_sys_api_keys_deleted_at` (`deleted_at`),
  KEY `idx_sys_api_keys_user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='API密钥';

-- 数据库备份表
DROP TABLE IF EXISTS `sys_backups`;
CREATE TABLE `sys_backups` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL COMMENT '备份名称',
  `file_path` varchar(512) NOT NULL COMMENT '文件路径',
  `file_size` bigint NOT NULL DEFAULT '0' COMMENT '文件大小',
  `type` varchar(20) DEFAULT NULL COMMENT '备份类型',
  `status` tinyint NOT NULL DEFAULT '0' COMMENT '状态',
  `error` text COMMENT '错误信息',
  `admin_id` bigint unsigned DEFAULT NULL COMMENT '管理员ID',
  `completed_at` datetime DEFAULT NULL COMMENT '完成时间',
  `created_at` datetime(3) DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  KEY `idx_sys_backups_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='数据库备份';

-- 域名绑定表
DROP TABLE IF EXISTS `sys_domain_bindings`;
CREATE TABLE `sys_domain_bindings` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `domain` varchar(255) NOT NULL COMMENT '域名',
  `user_id` bigint unsigned NOT NULL COMMENT '默认推荐人用户ID',
  `remark` varchar(255) DEFAULT NULL COMMENT '备注',
  `enabled` tinyint(1) NOT NULL DEFAULT '1' COMMENT '是否启用',
  `created_at` datetime(3) DEFAULT CURRENT_TIMESTAMP(3),
  `updated_at` datetime(3) DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_sys_domain_bindings_domain` (`domain`),
  KEY `idx_sys_domain_bindings_user_id` (`user_id`),
  KEY `idx_sys_domain_bindings_enabled` (`enabled`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='域名绑定';

-- ============================================================================
-- 业务模块 (biz_*)
-- ============================================================================

-- IAP内购交易表
DROP TABLE IF EXISTS `biz_iap_transactions`;
CREATE TABLE `biz_iap_transactions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `created_at` datetime(3) DEFAULT CURRENT_TIMESTAMP(3),
  `updated_at` datetime(3) DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  `deleted_at` datetime(3) DEFAULT NULL,
  `user_id` bigint unsigned NOT NULL COMMENT '用户ID',
  `platform` varchar(20) NOT NULL COMMENT '平台: apple, android',
  `product_id` varchar(100) NOT NULL COMMENT '产品ID',
  `transaction_id` varchar(128) NOT NULL COMMENT '交易ID',
  `receipt` longtext COMMENT '收据数据',
  `period` varchar(50) NOT NULL COMMENT '周期',
  `plan_id` bigint unsigned NOT NULL COMMENT '套餐ID',
  `status` tinyint NOT NULL DEFAULT '0' COMMENT '状态: 0=待验证, 1=已验证, 2=验证失败',
  `verify_result` text COMMENT '验证结果',
  `order_no` varchar(32) NOT NULL COMMENT '订单号',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_biz_iap_transactions_transaction_id` (`transaction_id`),
  UNIQUE KEY `idx_biz_iap_transactions_order_no` (`order_no`),
  KEY `idx_biz_iap_transactions_deleted_at` (`deleted_at`),
  KEY `idx_biz_iap_transactions_user_id` (`user_id`),
  KEY `idx_biz_iap_transactions_platform` (`platform`),
  KEY `idx_biz_iap_transactions_plan_id` (`plan_id`),
  KEY `idx_biz_iap_transactions_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='IAP内购交易';

-- ============================================================================
-- 初始数据
-- ============================================================================

-- 初始化默认服务器组
INSERT INTO `node_server_groups` (`id`, `name`) VALUES (1, 'Default Group');

-- 初始化系统设置
INSERT INTO `sys_settings` (`key`, `value`) VALUES
('app_name', 'EzPanel'),
('app_url', ''),
('subscribe_url_prefix', ''),
('currency', 'CNY'),
('register_enabled', '1'),
('email_verify_enabled', '0'),
('invite_force', '0'),
('invite_commission', '10'),
('withdraw_min_amount', '100'),
('withdraw_fee_percent', '0'),
('telegram_enable', '0'),
('email_enable', '0');

-- 初始化知识库分类
INSERT INTO `support_knowledge_categories` (`id`, `name`) VALUES
(1, 'Windows教程'),
(2, 'macOS教程'),
(3, 'iOS教程'),
(4, 'Android教程'),
(5, '常见问题');

-- 初始化邮件/通知模板
INSERT INTO `sys_email_templates` (`code`, `name`, `subject`, `content`, `telegram_content`, `variables`, `description`, `enabled`) VALUES
('verify', '邮箱验证', '【{{site_name}}】邮箱验证码', '<div style="max-width:600px;margin:0 auto;padding:20px;font-family:Arial,sans-serif;"><h2 style="color:#333;">邮箱验证</h2><p>您好，</p><p>您正在进行邮箱验证，验证码为：</p><div style="background:#f5f5f5;padding:20px;text-align:center;font-size:24px;font-weight:bold;letter-spacing:5px;margin:20px 0;">{{code}}</div><p>验证码有效期为10分钟，请勿泄露给他人。</p><p>如果您没有进行此操作，请忽略此邮件。</p><p style="color:#999;margin-top:30px;">——{{site_name}}</p></div>', '🔐 【{{site_name}}】邮箱验证\n\n您的验证码为：{{code}}\n\n验证码有效期10分钟，请勿泄露。', 'site_name: 站点名称\ncode: 验证码', '用于邮箱验证时发送验证码', 1),
('reset_password', '重置密码', '【{{site_name}}】重置密码', '<div style="max-width:600px;margin:0 auto;padding:20px;font-family:Arial,sans-serif;"><h2 style="color:#333;">重置密码</h2><p>您好，</p><p>您正在重置密码，验证码为：</p><div style="background:#f5f5f5;padding:20px;text-align:center;font-size:24px;font-weight:bold;letter-spacing:5px;margin:20px 0;">{{code}}</div><p>验证码有效期为10分钟，请勿泄露给他人。</p><p>如果您没有进行此操作，请立即检查账户安全。</p><p style="color:#999;margin-top:30px;">——{{site_name}}</p></div>', '🔑 【{{site_name}}】重置密码\n\n您的验证码为：{{code}}\n\n验证码有效期10分钟，如非本人操作请立即检查账户安全。', 'site_name: 站点名称\ncode: 验证码', '用于重置密码时发送验证码', 1),
('welcome', '欢迎邮件', '【{{site_name}}】欢迎注册', '<div style="max-width:600px;margin:0 auto;padding:20px;font-family:Arial,sans-serif;"><h2 style="color:#333;">欢迎加入 {{site_name}}</h2><p>尊敬的用户，您好！</p><p>感谢您注册 {{site_name}}，您的账户已创建成功。</p><p>开始使用我们的服务：</p><ul><li>选择适合您的套餐</li><li>下载客户端并导入订阅</li><li>享受高速、稳定的网络体验</li></ul><p><a href="{{login_url}}" style="display:inline-block;background:#409eff;color:#fff;padding:10px 20px;text-decoration:none;border-radius:5px;margin-top:20px;">立即开始</a></p><p style="color:#999;margin-top:30px;">——{{site_name}}</p></div>', '🎉 欢迎加入 {{site_name}}\n\n您的账号已创建成功！\n\n开始使用：\n• 选择适合您的套餐\n• 下载客户端并导入订阅\n• 享受高速、稳定的网络体验', 'site_name: 站点名称\nlogin_url: 登录链接', '用于用户注册成功后发送欢迎邮件', 1),
('order_created', '订单创建', '【{{site_name}}】订单创建成功', '<div style="max-width:600px;margin:0 auto;padding:20px;font-family:Arial,sans-serif;"><h2 style="color:#333;">订单创建成功</h2><p>尊敬的用户，您好！</p><p>您的订单已创建成功，请尽快完成支付：</p><table style="width:100%;border-collapse:collapse;margin:20px 0;"><tr style="background:#f5f5f5;"><td style="padding:10px;border:1px solid #ddd;">订单号</td><td style="padding:10px;border:1px solid #ddd;">{{order_no}}</td></tr><tr><td style="padding:10px;border:1px solid #ddd;">套餐名称</td><td style="padding:10px;border:1px solid #ddd;">{{plan_name}}</td></tr><tr style="background:#f5f5f5;"><td style="padding:10px;border:1px solid #ddd;">订单金额</td><td style="padding:10px;border:1px solid #ddd;">¥{{amount}}</td></tr></table><p><a href="{{pay_url}}" style="display:inline-block;background:#409eff;color:#fff;padding:10px 20px;text-decoration:none;border-radius:5px;margin-top:20px;">立即支付</a></p><p style="color:#999;margin-top:20px;">订单将在24小时后自动取消，请尽快完成支付。</p><p style="color:#999;margin-top:30px;">——{{site_name}}</p></div>', '📦 【{{site_name}}】订单创建成功\n\n订单号: {{order_no}}\n套餐: {{plan_name}}\n金额: ¥{{amount}}\n\n请尽快完成支付，订单将在24小时后自动取消。', 'site_name: 站点名称\norder_no: 订单号\nplan_name: 套餐名称\namount: 订单金额\npay_url: 支付链接', '用于订单创建后发送支付提醒', 1),
('order_paid', '订单支付成功', '【{{site_name}}】订单支付成功通知', '<div style="max-width:600px;margin:0 auto;padding:20px;font-family:Arial,sans-serif;"><h2 style="color:#333;">订单支付成功</h2><p>尊敬的用户，您好！</p><p>您的订单已支付成功，详情如下：</p><table style="width:100%;border-collapse:collapse;margin:20px 0;"><tr style="background:#f5f5f5;"><td style="padding:10px;border:1px solid #ddd;">订单号</td><td style="padding:10px;border:1px solid #ddd;">{{order_no}}</td></tr><tr><td style="padding:10px;border:1px solid #ddd;">套餐名称</td><td style="padding:10px;border:1px solid #ddd;">{{plan_name}}</td></tr><tr style="background:#f5f5f5;"><td style="padding:10px;border:1px solid #ddd;">支付金额</td><td style="padding:10px;border:1px solid #ddd;">¥{{amount}}</td></tr></table><p>感谢您的支持！</p><p style="color:#999;margin-top:30px;">——{{site_name}}</p></div>', '✅ 【{{site_name}}】订单支付成功\n\n订单号: {{order_no}}\n套餐: {{plan_name}}\n金额: ¥{{amount}}\n\n感谢您的支持！', 'site_name: 站点名称\norder_no: 订单号\nplan_name: 套餐名称\namount: 支付金额', '用于订单支付成功后发送通知', 1),
('order_expiring', '订单即将到期', '【{{site_name}}】您的订阅即将到期', '<div style="max-width:600px;margin:0 auto;padding:20px;font-family:Arial,sans-serif;"><h2 style="color:#f90;">订阅即将到期</h2><p>尊敬的用户，您好！</p><p>您的订阅将于 <strong>{{expire_date}}</strong> 到期，距离到期还有 <strong>{{days}}</strong> 天。</p><p>为避免服务中断，请及时续费。</p><p><a href="{{renew_url}}" style="display:inline-block;background:#409eff;color:#fff;padding:10px 20px;text-decoration:none;border-radius:5px;margin-top:20px;">立即续费</a></p><p style="color:#999;margin-top:30px;">——{{site_name}}</p></div>', '⚠️ 【{{site_name}}】订阅即将到期\n\n您的订阅将于 {{expire_date}} 到期，还剩 {{days}} 天。\n\n为避免服务中断，请及时续费。', 'site_name: 站点名称\nexpire_date: 到期时间\ndays: 剩余天数\nrenew_url: 续费链接', '用于订阅即将到期时发送提醒', 1),
('order_expired', '订单已到期', '【{{site_name}}】您的订阅已到期', '<div style="max-width:600px;margin:0 auto;padding:20px;font-family:Arial,sans-serif;"><h2 style="color:#f00;">订阅已到期</h2><p>尊敬的用户，您好！</p><p>您的订阅已于 <strong>{{expire_date}}</strong> 到期，服务已暂停。</p><p>为恢复服务，请尽快续费。</p><p><a href="{{renew_url}}" style="display:inline-block;background:#409eff;color:#fff;padding:10px 20px;text-decoration:none;border-radius:5px;margin-top:20px;">立即续费</a></p><p style="color:#999;margin-top:30px;">——{{site_name}}</p></div>', '⚠️ 【{{site_name}}】订阅已到期\n\n您的订阅已于 {{expire_date}} 到期，服务已暂停。\n\n为恢复服务，请尽快续费。', 'site_name: 站点名称\nexpire_date: 到期时间\nrenew_url: 续费链接', '用于订阅到期后发送通知', 1),
('ticket_created', '工单创建', '【{{site_name}}】工单已创建', '<div style="max-width:600px;margin:0 auto;padding:20px;font-family:Arial,sans-serif;"><h2 style="color:#333;">工单已创建</h2><p>尊敬的用户，您好！</p><p>您的工单已成功创建：</p><table style="width:100%;border-collapse:collapse;margin:20px 0;"><tr style="background:#f5f5f5;"><td style="padding:10px;border:1px solid #ddd;">工单编号</td><td style="padding:10px;border:1px solid #ddd;">#{{ticket_id}}</td></tr><tr><td style="padding:10px;border:1px solid #ddd;">主题</td><td style="padding:10px;border:1px solid #ddd;">{{ticket_subject}}</td></tr></table><p>我们会尽快处理您的工单，请耐心等待。</p><p style="color:#999;margin-top:30px;">——{{site_name}}</p></div>', '📝 【{{site_name}}】工单已创建\n\n工单编号: #{{ticket_id}}\n主题: {{ticket_subject}}\n\n我们会尽快处理您的工单，请耐心等待。', 'site_name: 站点名称\nticket_id: 工单ID\nticket_subject: 工单主题', '用于工单创建成功后发送确认通知', 1),
('ticket_reply', '工单回复', '【{{site_name}}】您的工单有新回复', '<div style="max-width:600px;margin:0 auto;padding:20px;font-family:Arial,sans-serif;"><h2 style="color:#333;">工单回复通知</h2><p>尊敬的用户，您好！</p><p>您的工单 <strong>#{{ticket_id}}</strong> 有新的回复：</p><div style="background:#f5f5f5;padding:15px;border-left:3px solid #409eff;margin:20px 0;">{{reply_content}}</div><p style="color:#999;margin-top:30px;">——{{site_name}}</p></div>', '📩 【{{site_name}}】工单回复通知\n\n工单 #{{ticket_id}} 有新回复：\n\n{{reply_content}}\n\n请登录查看详情。', 'site_name: 站点名称\nticket_id: 工单ID\nreply_content: 回复内容', '用于工单有新回复时发送通知', 1),
('traffic_warning', '流量即将用尽', '【{{site_name}}】您的流量即将用尽', '<div style="max-width:600px;margin:0 auto;padding:20px;font-family:Arial,sans-serif;"><h2 style="color:#f90;">流量即将用尽</h2><p>尊敬的用户，您好！</p><p>您的订阅流量已使用 <strong>{{used_percent}}%</strong>。</p><p>为避免流量用尽后服务中断，建议您及时升级套餐。</p><p style="color:#999;margin-top:30px;">——{{site_name}}</p></div>', '⚠️ 【{{site_name}}】流量预警\n\n您已使用 {{used_percent}}% 的流量\n\n请注意流量使用，避免超出限制。', 'site_name: 站点名称\nused_percent: 已用百分比', '用于流量即将用尽时发送提醒', 1),
('traffic_used_up', '流量已用尽', '【{{site_name}}】您的流量已用尽', '<div style="max-width:600px;margin:0 auto;padding:20px;font-family:Arial,sans-serif;"><h2 style="color:#f00;">流量已用尽</h2><p>尊敬的用户，您好！</p><p>您的订阅流量已全部用完，服务已暂停。</p><p>如需恢复服务，请升级套餐或购买流量包。</p><p style="color:#999;margin-top:30px;">——{{site_name}}</p></div>', '🚫 【{{site_name}}】流量已用尽\n\n您的订阅流量已全部用完，服务已暂停。\n\n如需恢复服务，请升级套餐或购买流量包。', 'site_name: 站点名称', '用于流量用尽后发送通知', 1),
('sub_reset', '订阅重置通知', '【{{site_name}}】您的订阅已重置', '<div style="max-width:600px;margin:0 auto;padding:20px;font-family:Arial,sans-serif;"><h2 style="color:#333;">订阅已重置</h2><p>尊敬的用户，您好！</p><p>您的订阅链接已重置，旧的订阅链接将失效。</p><p>请使用新的订阅链接重新导入客户端。</p><p style="color:#999;margin-top:30px;">——{{site_name}}</p></div>', '🔄 【{{site_name}}】订阅已重置\n\n您的订阅链接已重置，旧的订阅链接将失效。\n\n请及时更新客户端配置。', 'site_name: 站点名称', '用于订阅重置后发送通知', 1),
('node_offline', '节点离线告警', '【{{site_name}}】节点离线告警 - {{node_name}}', '<div style="max-width:600px;margin:0 auto;padding:20px;font-family:Arial,sans-serif;"><h2 style="color:#e74c3c;">🔴 节点离线告警</h2><div style="background:#fff3f3;padding:15px;border-radius:5px;margin:15px 0;border-left:4px solid #e74c3c;"><p><strong>节点名称:</strong> {{node_name}}</p><p><strong>最后心跳:</strong> {{last_check_at}}</p><p><strong>告警时间:</strong> {{alert_time}}</p></div><p style="color:#e74c3c;font-weight:bold;">请及时检查节点状态！</p><p style="color:#999;margin-top:30px;">——{{site_name}}</p></div>', '🔴 【{{site_name}}】节点离线告警\n\n节点名称: {{node_name}}\n最后心跳: {{last_check_at}}\n告警时间: {{alert_time}}\n\n请及时检查节点状态！', 'site_name: 站点名称\nnode_name: 节点名称\nlast_check_at: 最后心跳时间\nalert_time: 告警时间', '用于节点离线时发送告警通知', 1),
('node_recovery', '节点恢复通知', '【{{site_name}}】节点恢复通知 - {{node_name}}', '<div style="max-width:600px;margin:0 auto;padding:20px;font-family:Arial,sans-serif;"><h2 style="color:#27ae60;">🟢 节点恢复通知</h2><div style="background:#f0fff4;padding:15px;border-radius:5px;margin:15px 0;border-left:4px solid #27ae60;"><p><strong>节点名称:</strong> {{node_name}}</p><p><strong>恢复时间:</strong> {{recovery_time}}</p></div><p style="color:#27ae60;">节点已恢复正常运行。</p><p style="color:#999;margin-top:30px;">——{{site_name}}</p></div>', '🟢 【{{site_name}}】节点恢复通知\n\n节点名称: {{node_name}}\n恢复时间: {{recovery_time}}\n\n节点已恢复正常运行。', 'site_name: 站点名称\nnode_name: 节点名称\nrecovery_time: 恢复时间', '用于节点恢复在线时发送通知', 1),
('alert_test', '告警测试', '【{{site_name}}】节点告警测试', '<div style="max-width:600px;margin:0 auto;padding:20px;font-family:Arial,sans-serif;"><h2 style="color:#409eff;">🔔 节点告警测试</h2><div style="background:#f0f9ff;padding:15px;border-radius:5px;margin:15px 0;border-left:4px solid #409eff;"><p>这是一条测试告警消息，用于验证节点告警通知是否正常工作。</p><p><strong>发送时间:</strong> {{send_time}}</p></div><p>如果您收到此消息，说明告警通知配置正确。</p><p style="color:#999;margin-top:30px;">——{{site_name}}</p></div>', '🔔 【{{site_name}}】节点告警测试\n\n这是一条测试告警消息，用于验证节点告警通知是否正常工作。\n\n发送时间: {{send_time}}\n\n如果您收到此消息，说明告警通知配置正确。', 'site_name: 站点名称\nsend_time: 发送时间', '用于测试告警通知是否正常', 1);

-- 初始化示例知识库文章
INSERT INTO `support_knowledge` (`category_id`, `title`, `body`, `sort`, `show`) VALUES
(1, 'Clash for Windows 使用教程', '## 下载安装\n\n1. 访问 [GitHub Release](https://github.com/Fndroid/clash_for_windows_pkg/releases) 下载最新版本\n2. 解压后运行 Clash for Windows.exe\n\n## 导入订阅\n\n1. 复制您的订阅链接\n2. 在软件中点击 Profiles\n3. 粘贴订阅链接并点击 Download\n\n## 开启代理\n\n1. 点击 General 标签页\n2. 开启 System Proxy\n3. 选择 Rule 模式\n\n完成！现在可以正常使用了。', 1, 1),
(2, 'ClashX 使用教程', '## 下载安装\n\n1. 访问 [GitHub Release](https://github.com/yichengchen/clashX/releases) 下载最新版本\n2. 将 ClashX.app 拖入 Applications 文件夹\n\n## 导入订阅\n\n1. 点击状态栏图标\n2. 选择 Config -> Remote config -> Manage\n3. 点击 Add，粘贴订阅链接\n\n## 开启代理\n\n1. 点击状态栏图标\n2. 选择 Set as system proxy\n\n完成！', 1, 1),
(3, 'Shadowrocket 使用教程', '## 安装\n\n在 App Store 搜索 Shadowrocket（小火箭）购买安装\n\n## 导入订阅\n\n1. 复制订阅链接\n2. 打开 Shadowrocket\n3. 点击右上角 + 号\n4. 选择类型为 Subscribe\n5. 粘贴订阅链接，点击完成\n\n## 连接使用\n\n1. 选择一个节点\n2. 点击开关连接\n3. 首次使用需允许VPN配置\n\n完成！', 1, 1),
(4, 'v2rayNG 使用教程', '## 安装\n\n1. 在 Google Play 搜索 v2rayNG 安装\n2. 或从 [GitHub Release](https://github.com/2dust/v2rayNG/releases) 下载 APK\n\n## 导入订阅\n\n1. 复制订阅链接\n2. 打开 v2rayNG\n3. 点击右上角 + 号\n4. 选择 从剪贴板导入\n\n## 连接使用\n\n1. 选择一个节点\n2. 点击右下角的 V 图标连接\n\n完成！', 1, 1),
(5, '无法连接怎么办？', '## 排查步骤\n\n1. **检查订阅是否过期**\n   - 登录面板查看到期时间\n   - 流量是否用完\n\n2. **更新订阅**\n   - 删除旧的订阅\n   - 重新添加订阅\n\n3. **更换节点**\n   - 尝试其他节点\n   - 有些节点可能临时维护\n\n4. **检查系统代理设置**\n   - 确认系统代理已开启\n   - 检查是否有其他代理软件冲突\n\n5. **联系客服**\n   - 如以上方法都无效\n   - 请提交工单联系客服', 1, 1);

SET FOREIGN_KEY_CHECKS = 1;

-- ============================================================================
-- 完成
-- ============================================================================
-- 注意: 默认管理员账号由程序首次启动时自动创建
-- 邮箱: admin@opine.work
-- 密码: admin123
-- ============================================================================
