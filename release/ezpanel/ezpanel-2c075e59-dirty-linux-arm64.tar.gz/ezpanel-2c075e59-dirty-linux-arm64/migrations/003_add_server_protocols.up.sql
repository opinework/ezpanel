-- 创建 server_protocols 表
CREATE TABLE IF NOT EXISTS server_protocols (
    id BIGINT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    deleted_at TIMESTAMP NULL,

    -- 关联字段
    server_id BIGINT UNSIGNED NOT NULL,

    -- 名称配置
    name VARCHAR(100) DEFAULT '' COMMENT '自定义名称，订阅中显示的节点名称',

    -- 连接配置（用户侧）
    host VARCHAR(255) NOT NULL COMMENT '连接地址，用户连接使用的域名/IP',
    port INT NOT NULL COMMENT '连接端口，用户连接使用的端口',

    -- 协议配置
    protocol VARCHAR(20) NOT NULL COMMENT '协议类型: vmess, vless, trojan, shadowsocks, hysteria2, tuic',
    server_port INT NOT NULL COMMENT '服务端口，协议实际监听的端口',

    -- 传输配置
    transport VARCHAR(20) DEFAULT 'tcp' COMMENT '传输方式: tcp, ws, grpc, h2, httpupgrade, splithttp, quic, kcp',
    transport_settings JSON COMMENT '传输配置',

    -- 安全配置
    tls TINYINT DEFAULT 0 COMMENT 'TLS类型: 0=无, 1=TLS, 2=Reality',
    tls_settings JSON COMMENT 'TLS配置',

    -- 协议专用配置
    protocol_settings JSON COMMENT '协议专用配置',

    -- 状态和优先级
    enabled BOOLEAN DEFAULT TRUE COMMENT '是否启用',
    sort INT DEFAULT 0 COMMENT '排序',

    -- 索引
    INDEX idx_server_id (server_id),
    INDEX idx_protocol (protocol),
    INDEX idx_enabled (enabled),
    INDEX idx_host (host),
    INDEX idx_deleted_at (deleted_at),
    FOREIGN KEY (server_id) REFERENCES servers(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='节点多协议配置表';

-- 迁移现有节点的协议配置到关联表
-- 将现有节点的 host 和 port 作为连接地址和端口
INSERT INTO server_protocols (
    server_id, name, host, port, protocol, server_port, transport,
    transport_settings, tls, tls_settings, protocol_settings,
    enabled, sort, created_at, updated_at
)
SELECT
    id,
    '',
    host,
    port,
    protocol,
    CASE WHEN server_port IS NULL OR server_port = 0 THEN port ELSE server_port END,
    CASE WHEN transport IS NULL OR transport = '' THEN 'tcp' ELSE transport END,
    transport_settings,
    CASE WHEN tls = true THEN 1 ELSE 0 END,
    tls_settings,
    protocol_settings,
    TRUE,
    0,
    created_at,
    updated_at
FROM servers
WHERE protocol IS NOT NULL
  AND protocol != ''
  AND deleted_at IS NULL;
