-- 数据库索引优化迁移
-- 执行方式: mysql -u root -p xpanel < 002_add_indexes.sql

-- ========================================
-- 用户表索引优化
-- ========================================

-- 复合索引：用于用户列表查询（状态+创建时间）
CREATE INDEX IF NOT EXISTS idx_users_banned_created ON users(banned, created_at DESC);

-- 复合索引：用于套餐用户统计
CREATE INDEX IF NOT EXISTS idx_users_plan_expired ON users(plan_id, expired_at);

-- 复合索引：用于邀请统计
CREATE INDEX IF NOT EXISTS idx_users_invite_created ON users(invite_user_id, created_at);

-- ========================================
-- 订单表索引优化
-- ========================================

-- 复合索引：用于订单列表（状态+创建时间）
CREATE INDEX IF NOT EXISTS idx_orders_status_created ON orders(status, created_at DESC);

-- 复合索引：用于用户订单查询
CREATE INDEX IF NOT EXISTS idx_orders_user_status ON orders(user_id, status);

-- 复合索引：用于支付回调查询
CREATE INDEX IF NOT EXISTS idx_orders_trade_status ON orders(trade_no, status);

-- 复合索引：用于收入统计
CREATE INDEX IF NOT EXISTS idx_orders_paid_at_status ON orders(paid_at, status);

-- 复合索引：用于佣金统计
CREATE INDEX IF NOT EXISTS idx_orders_commission_status ON orders(commission_status, invite_user_id);

-- ========================================
-- 流量日志表索引优化
-- ========================================

-- 复合索引：用于用户流量统计
CREATE INDEX IF NOT EXISTS idx_traffic_user_logat ON traffic_logs(user_id, log_at);

-- 复合索引：用于服务器流量统计
CREATE INDEX IF NOT EXISTS idx_traffic_server_logat ON traffic_logs(server_id, log_at);

-- 复合索引：用于日期范围查询
CREATE INDEX IF NOT EXISTS idx_traffic_logat_user ON traffic_logs(log_at, user_id);

-- ========================================
-- 工单表索引优化
-- ========================================

-- 复合索引：用于工单列表
CREATE INDEX IF NOT EXISTS idx_tickets_status_updated ON tickets(status, updated_at DESC);

-- 复合索引：用于用户工单
CREATE INDEX IF NOT EXISTS idx_tickets_user_status ON tickets(user_id, status);

-- ========================================
-- 服务器表索引优化
-- ========================================

-- 复合索引：用于节点列表
CREATE INDEX IF NOT EXISTS idx_servers_show_sort ON servers(show, sort);

-- 复合索引：用于分组节点
CREATE INDEX IF NOT EXISTS idx_servers_group_show ON servers(group_id, show);

-- ========================================
-- 审计日志表索引优化
-- ========================================

-- 复合索引：用于审计日志查询
CREATE INDEX IF NOT EXISTS idx_audit_logs_module_created ON audit_logs(module, created_at DESC);

-- 复合索引：用于管理员操作查询
CREATE INDEX IF NOT EXISTS idx_audit_logs_admin_created ON audit_logs(admin_id, created_at DESC);

-- ========================================
-- 登录日志表索引优化
-- ========================================

-- 复合索引：用于用户登录历史
CREATE INDEX IF NOT EXISTS idx_login_logs_user_created ON user_login_logs(user_id, created_at DESC);

-- ========================================
-- 优惠券使用记录索引优化
-- ========================================

-- 复合索引：用于用户使用次数统计
CREATE INDEX IF NOT EXISTS idx_coupon_usage_user_coupon ON coupon_usages(user_id, coupon_id);

-- ========================================
-- 卡密表索引优化
-- ========================================

-- 复合索引：用于未使用卡密查询
CREATE INDEX IF NOT EXISTS idx_redeem_type_used ON redeem_codes(type, used_user_id);

-- ========================================
-- 分析和优化建议
-- ========================================

-- 执行表分析以更新统计信息
ANALYZE TABLE users;
ANALYZE TABLE orders;
ANALYZE TABLE traffic_logs;
ANALYZE TABLE tickets;
ANALYZE TABLE servers;
ANALYZE TABLE audit_logs;
ANALYZE TABLE user_login_logs;
ANALYZE TABLE coupon_usages;
ANALYZE TABLE redeem_codes;
