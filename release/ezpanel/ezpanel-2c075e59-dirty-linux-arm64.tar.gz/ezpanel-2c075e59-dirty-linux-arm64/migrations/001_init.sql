-- XrayR Panel Database Schema
-- Version: 1.0.0

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- 用户表
-- ----------------------------
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `email` varchar(255) NOT NULL COMMENT '邮箱',
  `password` varchar(255) NOT NULL COMMENT '密码',
  `uuid` char(36) NOT NULL COMMENT '用户UUID，用于订阅',
  `balance` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '余额',
  `commission_balance` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '佣金余额',
  `discount` int NOT NULL DEFAULT '0' COMMENT '专属折扣',
  `is_admin` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否管理员',
  `is_staff` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否员工',
  `banned` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否封禁',
  `ban_reason` varchar(255) DEFAULT NULL COMMENT '封禁原因',
  `transfer_enable` bigint NOT NULL DEFAULT '0' COMMENT '可用流量(字节)',
  `upload` bigint NOT NULL DEFAULT '0' COMMENT '上传流量(字节)',
  `download` bigint NOT NULL DEFAULT '0' COMMENT '下载流量(字节)',
  `expired_at` datetime DEFAULT NULL COMMENT '过期时间',
  `last_login_at` datetime DEFAULT NULL COMMENT '最后登录时间',
  `last_login_ip` varchar(45) DEFAULT NULL COMMENT '最后登录IP',
  `invite_user_id` bigint unsigned DEFAULT NULL COMMENT '邀请人ID',
  `telegram_id` bigint DEFAULT NULL COMMENT 'Telegram ID',
  `remarks` varchar(255) DEFAULT NULL COMMENT '备注',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_email` (`email`),
  UNIQUE KEY `idx_uuid` (`uuid`),
  KEY `idx_invite_user_id` (`invite_user_id`),
  KEY `idx_telegram_id` (`telegram_id`),
  KEY `idx_expired_at` (`expired_at`),
  KEY `idx_deleted_at` (`deleted_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='用户表';

-- ----------------------------
-- 用户登录日志表
-- ----------------------------
DROP TABLE IF EXISTS `user_login_logs`;
CREATE TABLE `user_login_logs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `ip` varchar(45) NOT NULL,
  `user_agent` varchar(512) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_created_at` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='登录日志';

-- ----------------------------
-- 套餐表
-- ----------------------------
DROP TABLE IF EXISTS `plans`;
CREATE TABLE `plans` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL COMMENT '套餐名称',
  `description` text COMMENT '套餐描述',
  `content` text COMMENT '套餐详情(HTML)',
  `group_id` bigint unsigned DEFAULT NULL COMMENT '权限组ID',
  `transfer_enable` bigint NOT NULL DEFAULT '0' COMMENT '流量(字节)',
  `device_limit` int NOT NULL DEFAULT '0' COMMENT '设备限制,0不限',
  `speed_limit` int NOT NULL DEFAULT '0' COMMENT '速度限制(Mbps),0不限',
  `price_monthly` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '月付价格',
  `price_quarterly` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '季付价格',
  `price_half_yearly` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '半年付价格',
  `price_yearly` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '年付价格',
  `price_two_yearly` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '两年付价格',
  `price_three_yearly` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '三年付价格',
  `price_onetime` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '一次性价格',
  `price_reset` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '重置流量价格',
  `capacity_limit` int NOT NULL DEFAULT '0' COMMENT '销量限制,0不限',
  `sold_count` int NOT NULL DEFAULT '0' COMMENT '已售数量',
  `renew` tinyint(1) NOT NULL DEFAULT '1' COMMENT '允许续费',
  `reset_traffic_method` tinyint NOT NULL DEFAULT '0' COMMENT '流量重置方式:0月初,1按月,2不重置',
  `sort` int NOT NULL DEFAULT '0' COMMENT '排序',
  `show` tinyint(1) NOT NULL DEFAULT '1' COMMENT '是否显示',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_group_id` (`group_id`),
  KEY `idx_show` (`show`),
  KEY `idx_sort` (`sort`),
  KEY `idx_deleted_at` (`deleted_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='套餐表';

-- ----------------------------
-- 服务器节点组表
-- ----------------------------
DROP TABLE IF EXISTS `server_groups`;
CREATE TABLE `server_groups` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL COMMENT '组名',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='节点组';

-- ----------------------------
-- 服务器节点表 (支持多协议)
-- ----------------------------
DROP TABLE IF EXISTS `servers`;
CREATE TABLE `servers` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL COMMENT '节点名称',
  `group_ids` json DEFAULT NULL COMMENT '所属组ID数组',
  `parent_id` bigint unsigned DEFAULT NULL COMMENT '父节点ID(用于负载均衡)',
  `host` varchar(255) NOT NULL COMMENT '服务器地址',
  `port` int NOT NULL COMMENT '端口',
  `server_port` int DEFAULT NULL COMMENT '服务端口(不同于连接端口时使用)',
  `protocol` varchar(20) NOT NULL COMMENT '协议: vmess,vless,trojan,shadowsocks',
  `protocol_settings` json DEFAULT NULL COMMENT '协议设置',
  `transport` varchar(20) NOT NULL DEFAULT 'tcp' COMMENT '传输协议: tcp,ws,grpc,http',
  `transport_settings` json DEFAULT NULL COMMENT '传输设置',
  `tls` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否启用TLS',
  `tls_settings` json DEFAULT NULL COMMENT 'TLS设置',
  `tags` json DEFAULT NULL COMMENT '标签',
  `rate` decimal(5,2) NOT NULL DEFAULT '1.00' COMMENT '倍率',
  `speed_limit` int NOT NULL DEFAULT '0' COMMENT '限速(Mbps)',
  `sort` int NOT NULL DEFAULT '0' COMMENT '排序',
  `show` tinyint(1) NOT NULL DEFAULT '1' COMMENT '是否显示',
  `status` tinyint NOT NULL DEFAULT '1' COMMENT '状态:0离线,1在线,2维护',
  `online_count` int NOT NULL DEFAULT '0' COMMENT '在线人数',
  `last_check_at` datetime DEFAULT NULL COMMENT '最后检查时间',
  `last_push_at` datetime DEFAULT NULL COMMENT '最后推送时间',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_parent_id` (`parent_id`),
  KEY `idx_protocol` (`protocol`),
  KEY `idx_show` (`show`),
  KEY `idx_status` (`status`),
  KEY `idx_deleted_at` (`deleted_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='节点表';

-- ----------------------------
-- 订单表
-- ----------------------------
DROP TABLE IF EXISTS `orders`;
CREATE TABLE `orders` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL COMMENT '用户ID',
  `order_no` varchar(32) NOT NULL COMMENT '订单号',
  `trade_no` varchar(64) DEFAULT NULL COMMENT '支付平台订单号',
  `plan_id` bigint unsigned NOT NULL COMMENT '套餐ID',
  `period` varchar(20) NOT NULL COMMENT '周期: monthly,quarterly,half_yearly,yearly,two_yearly,three_yearly,onetime,reset',
  `type` tinyint NOT NULL DEFAULT '1' COMMENT '类型:1新购,2续费,3升级,4流量重置',
  `amount` decimal(10,2) NOT NULL COMMENT '原价',
  `discount_amount` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '折扣金额',
  `paid_amount` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '实付金额',
  `balance_amount` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '余额支付金额',
  `coupon_id` bigint unsigned DEFAULT NULL COMMENT '优惠券ID',
  `coupon_code` varchar(50) DEFAULT NULL COMMENT '优惠码',
  `payment_id` bigint unsigned DEFAULT NULL COMMENT '支付方式ID',
  `status` tinyint NOT NULL DEFAULT '0' COMMENT '状态:0待支付,1已支付,2已取消,3已退款',
  `paid_at` datetime DEFAULT NULL COMMENT '支付时间',
  `callback_no` varchar(64) DEFAULT NULL COMMENT '回调流水号',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_order_no` (`order_no`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_plan_id` (`plan_id`),
  KEY `idx_status` (`status`),
  KEY `idx_created_at` (`created_at`),
  KEY `idx_deleted_at` (`deleted_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='订单表';

-- ----------------------------
-- 优惠券表
-- ----------------------------
DROP TABLE IF EXISTS `coupons`;
CREATE TABLE `coupons` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(50) NOT NULL COMMENT '优惠码',
  `name` varchar(100) NOT NULL COMMENT '优惠券名称',
  `type` tinyint NOT NULL DEFAULT '1' COMMENT '类型:1固定金额,2百分比',
  `value` decimal(10,2) NOT NULL COMMENT '优惠值',
  `limit_use` int NOT NULL DEFAULT '0' COMMENT '总使用次数限制,0不限',
  `limit_use_per_user` int NOT NULL DEFAULT '1' COMMENT '每用户限制次数',
  `limit_plan_ids` json DEFAULT NULL COMMENT '限制套餐ID',
  `limit_period` json DEFAULT NULL COMMENT '限制周期',
  `used_count` int NOT NULL DEFAULT '0' COMMENT '已使用次数',
  `started_at` datetime DEFAULT NULL COMMENT '开始时间',
  `ended_at` datetime DEFAULT NULL COMMENT '结束时间',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_code` (`code`),
  KEY `idx_deleted_at` (`deleted_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='优惠券表';

-- ----------------------------
-- 优惠券使用记录表
-- ----------------------------
DROP TABLE IF EXISTS `coupon_usages`;
CREATE TABLE `coupon_usages` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `coupon_id` bigint unsigned NOT NULL,
  `user_id` bigint unsigned NOT NULL,
  `order_id` bigint unsigned NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_coupon_id` (`coupon_id`),
  KEY `idx_user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='优惠券使用记录';

-- ----------------------------
-- 卡密表
-- ----------------------------
DROP TABLE IF EXISTS `redeem_codes`;
CREATE TABLE `redeem_codes` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(50) NOT NULL COMMENT '卡密',
  `type` tinyint NOT NULL COMMENT '类型:1套餐,2余额,3流量',
  `value` bigint NOT NULL COMMENT '值(套餐ID/金额分/流量字节)',
  `plan_id` bigint unsigned DEFAULT NULL COMMENT '套餐ID(type=1时)',
  `period` varchar(20) DEFAULT NULL COMMENT '周期(type=1时)',
  `used_user_id` bigint unsigned DEFAULT NULL COMMENT '使用者ID',
  `used_at` datetime DEFAULT NULL COMMENT '使用时间',
  `expired_at` datetime DEFAULT NULL COMMENT '过期时间',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_code` (`code`),
  KEY `idx_used_user_id` (`used_user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='卡密表';

-- ----------------------------
-- 支付方式表
-- ----------------------------
DROP TABLE IF EXISTS `payments`;
CREATE TABLE `payments` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL COMMENT '支付名称',
  `icon` varchar(255) DEFAULT NULL COMMENT '图标',
  `payment` varchar(50) NOT NULL COMMENT '支付类型: epay,stripe,alipay',
  `config` json NOT NULL COMMENT '支付配置',
  `handling_fee_fixed` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '固定手续费',
  `handling_fee_percent` decimal(5,2) NOT NULL DEFAULT '0.00' COMMENT '百分比手续费',
  `sort` int NOT NULL DEFAULT '0' COMMENT '排序',
  `enable` tinyint(1) NOT NULL DEFAULT '1' COMMENT '是否启用',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='支付方式';

-- ----------------------------
-- 流量日志表
-- ----------------------------
DROP TABLE IF EXISTS `traffic_logs`;
CREATE TABLE `traffic_logs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `server_id` bigint unsigned NOT NULL,
  `upload` bigint NOT NULL DEFAULT '0' COMMENT '上传流量(字节)',
  `download` bigint NOT NULL DEFAULT '0' COMMENT '下载流量(字节)',
  `log_at` datetime NOT NULL COMMENT '记录时间',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_server_id` (`server_id`),
  KEY `idx_log_at` (`log_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='流量日志';

-- ----------------------------
-- 工单表
-- ----------------------------
DROP TABLE IF EXISTS `tickets`;
CREATE TABLE `tickets` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `subject` varchar(255) NOT NULL COMMENT '主题',
  `level` tinyint NOT NULL DEFAULT '1' COMMENT '优先级:1低,2中,3高',
  `status` tinyint NOT NULL DEFAULT '0' COMMENT '状态:0待处理,1处理中,2已关闭',
  `category` varchar(50) DEFAULT NULL COMMENT '工单分类',
  `assigned_to` bigint unsigned DEFAULT NULL COMMENT '指派给的管理员ID',
  `due_at` datetime DEFAULT NULL COMMENT 'SLA截止时间',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_status` (`status`),
  KEY `idx_category` (`category`),
  KEY `idx_assigned_to` (`assigned_to`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='工单表';

-- ----------------------------
-- 工单消息表
-- ----------------------------
DROP TABLE IF EXISTS `ticket_messages`;
CREATE TABLE `ticket_messages` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `ticket_id` bigint unsigned NOT NULL,
  `user_id` bigint unsigned NOT NULL COMMENT '发送者ID',
  `is_admin` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否管理员回复',
  `content` text NOT NULL COMMENT '消息内容',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_ticket_id` (`ticket_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='工单消息';

-- ----------------------------
-- 公告表
-- ----------------------------
DROP TABLE IF EXISTS `announcements`;
CREATE TABLE `announcements` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL COMMENT '标题',
  `content` text NOT NULL COMMENT '内容',
  `img_url` varchar(255) DEFAULT NULL COMMENT '图片URL',
  `tags` json DEFAULT NULL COMMENT '标签',
  `show` tinyint(1) NOT NULL DEFAULT '1' COMMENT '是否显示',
  `pinned` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否置顶',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_show` (`show`),
  KEY `idx_pinned` (`pinned`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='公告表';

-- ----------------------------
-- 知识库表
-- ----------------------------
DROP TABLE IF EXISTS `knowledge`;
CREATE TABLE `knowledge` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `category` varchar(50) NOT NULL COMMENT '分类',
  `title` varchar(255) NOT NULL COMMENT '标题',
  `content` text NOT NULL COMMENT '内容',
  `sort` int NOT NULL DEFAULT '0' COMMENT '排序',
  `show` tinyint(1) NOT NULL DEFAULT '1' COMMENT '是否显示',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_category` (`category`),
  KEY `idx_show` (`show`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='知识库';

-- ----------------------------
-- 邀请记录表
-- ----------------------------
DROP TABLE IF EXISTS `invite_records`;
CREATE TABLE `invite_records` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `inviter_id` bigint unsigned NOT NULL COMMENT '邀请人ID',
  `user_id` bigint unsigned NOT NULL COMMENT '被邀请人ID',
  `commission_rate` decimal(5,2) NOT NULL DEFAULT '0.00' COMMENT '佣金比例',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_inviter_id` (`inviter_id`),
  KEY `idx_user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='邀请记录';

-- ----------------------------
-- 佣金记录表
-- ----------------------------
DROP TABLE IF EXISTS `commission_logs`;
CREATE TABLE `commission_logs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL COMMENT '获得佣金用户ID',
  `from_user_id` bigint unsigned NOT NULL COMMENT '来源用户ID',
  `order_id` bigint unsigned NOT NULL COMMENT '订单ID',
  `amount` decimal(10,2) NOT NULL COMMENT '佣金金额',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_from_user_id` (`from_user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='佣金记录';

-- ----------------------------
-- 系统设置表
-- ----------------------------
DROP TABLE IF EXISTS `settings`;
CREATE TABLE `settings` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `key` varchar(100) NOT NULL COMMENT '设置键',
  `value` text COMMENT '设置值',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_key` (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='系统设置';

-- ----------------------------
-- 初始化系统设置
-- ----------------------------
INSERT INTO `settings` (`key`, `value`) VALUES
('site_name', 'XrayR Panel'),
('site_description', '高速稳定的代理服务'),
('site_url', 'https://example.com'),
('logo_url', '/logo.png'),
('currency', 'CNY'),
('currency_symbol', '¥'),
('register_enable', '1'),
('register_email_verify', '0'),
('register_trial_plan_id', ''),
('register_trial_days', '0'),
('invite_enable', '1'),
('invite_commission_rate', '10'),
('subscribe_path', '/api/v1/client/subscribe'),
('telegram_bot_token', ''),
('telegram_bot_enable', '0');

SET FOREIGN_KEY_CHECKS = 1;
