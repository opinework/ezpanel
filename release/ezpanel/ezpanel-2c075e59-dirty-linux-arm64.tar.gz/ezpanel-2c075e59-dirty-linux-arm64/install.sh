#!/bin/bash
# EzPanel Installation Script

set -e

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

if [ "$EUID" -ne 0 ]; then
    echo -e "${RED}Please run as root${NC}"
    exit 1
fi

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

echo -e "${GREEN}Installing EzPanel...${NC}"

# Create user and group
if ! getent group ezpanel >/dev/null; then
    groupadd -r ezpanel
    echo -e "${GREEN}✓ Created group: ezpanel${NC}"
fi

if ! getent passwd ezpanel >/dev/null; then
    useradd -r -g ezpanel -d /var/lib/ezpanel -s /usr/sbin/nologin -c "EzPanel" ezpanel
    echo -e "${GREEN}✓ Created user: ezpanel${NC}"
fi

# Create directories
mkdir -p /var/lib/ezpanel/upload/clients
mkdir -p /var/log/ezpanel
mkdir -p /run/ezpanel
mkdir -p /etc/ezpanel

# Set ownership and permissions
chown -R ezpanel:ezpanel /var/lib/ezpanel
chown -R ezpanel:ezpanel /var/log/ezpanel
chown -R ezpanel:ezpanel /run/ezpanel
chmod 750 /var/lib/ezpanel
chmod 750 /var/lib/ezpanel/upload
chmod 750 /var/lib/ezpanel/upload/clients
chmod 750 /var/log/ezpanel
chmod 755 /run/ezpanel

echo -e "${GREEN}✓ Created directories${NC}"

# Install binary
install -Dm755 "$SCRIPT_DIR/ezpanel" /usr/bin/ezpanel
echo -e "${GREEN}✓ Installed binary${NC}"

# Install config (don't overwrite existing)
if [ ! -f /etc/ezpanel/config.yaml ]; then
    install -Dm640 "$SCRIPT_DIR/config.yaml" /etc/ezpanel/config.yaml
    chown ezpanel:ezpanel /etc/ezpanel/config.yaml
    echo -e "${GREEN}✓ Installed config${NC}"
else
    echo -e "${YELLOW}! Config exists, skipped${NC}"
fi

# Install migrations
if [ -d "$SCRIPT_DIR/migrations" ]; then
    mkdir -p /usr/share/ezpanel/migrations
    cp -r "$SCRIPT_DIR/migrations/"* /usr/share/ezpanel/migrations/
    echo -e "${GREEN}✓ Installed migrations${NC}"
fi

# Install systemd service
if [ -d /usr/lib/systemd/system ]; then
    cat > /usr/lib/systemd/system/ezpanel.service << 'SERVICE'
[Unit]
Description=EzPanel Panel
Documentation=https://github.com/opinework/ezpanel
After=network.target mysql.service redis.service

[Service]
Type=simple
User=ezpanel
Group=ezpanel
ExecStart=/usr/bin/ezpanel -config /etc/ezpanel/config.yaml
Restart=on-failure
RestartSec=5

ProtectSystem=strict
ReadWritePaths=/var/lib/ezpanel /var/log/ezpanel /run/ezpanel
PrivateTmp=true
NoNewPrivileges=true

[Install]
WantedBy=multi-user.target
SERVICE
    systemctl daemon-reload
    echo -e "${GREEN}✓ Installed systemd service${NC}"
fi

echo ""
echo -e "${GREEN}=============================================="
echo "  EzPanel 安装完成"
echo "=============================================="
echo ""
echo "首次安装步骤:"
echo ""
echo "1. 创建数据库:"
echo "   mysql -u root -p"
echo "   CREATE DATABASE ezpanel CHARACTER SET utf8mb4;"
echo "   CREATE USER 'ezpanel'@'127.0.0.1' IDENTIFIED BY 'password';"
echo "   GRANT ALL ON ezpanel.* TO 'ezpanel'@'127.0.0.1';"
echo ""
echo "2. 编辑配置: /etc/ezpanel/config.yaml"
echo ""
echo "3. 启动服务: systemctl start ezpanel"
echo "             systemctl enable ezpanel"
echo ""
echo "4. 默认管理员:"
echo "   邮箱: admin@opine.work"
echo "   密码: admin123"
echo ""
echo "5. 访问: http://your-server:7088"
echo "==============================================${NC}"
