-- 删除 server_protocols 表
DROP TABLE IF EXISTS server_protocols;
